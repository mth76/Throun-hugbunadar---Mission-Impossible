import pygame
import os
import TestFrame
import PongM
import Button
import levelinbetween
pygame.init()
button = Button.Button()
level = levelinbetween.levelinbetween()

class Soguthradur:
    def __init__(self):
        self.WIDTH = 1440
        self.HEIGHT = 853
        self.screen1 = TestFrame.frame(self.WIDTH,self.HEIGHT)
        self.screen = self.screen1.uppsetning()
        self.clock = pygame.time.Clock()
        self.mynd = pygame.image.load('Scientology.jpg')
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)

    def image(self,background,x,y):
        self.screen.blit(background,(x,y))

    def story(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            self.screen.fill(self.WHITE)
            self.image(self.mynd,0,0)
            button.button('Hætta',500,350,200,35,self.GOLD,self.BRIGHT_GOLD,pygame.quit)
            button.button('Spila',500,400,200,75,self.RED,self.BRIGHT_RED,level.run)
            pygame.display.update()
            self.clock.tick(15)
