import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *
import Generals as G            # Kóðinn Generals.py hefur ýmsan kóða, t.d. að labba, birtan og frame.
from Level4 import Level4class
class Level3class():
    def __init__(self):
        self.f1 = open("skordur111.txt", 'w+')
        #self.f2 = open("skordur211.txt", 'w+')
        Svartur = (0,  0,  0 )
        Dokkbr  = (50,50,50)
        white   = (255,255,255)
        green   = (33, 125, 34)

        o  = 0          # Wall
        x =  1          # Floor
        g  = 2          # Water
        w  = 3

        self.colours = {            # Hér er verið að skilgreina o,x,g og w sem ákveðna liti
                    o : Svartur,
                    x : Dokkbr,
                    g : green,
                    w : white
                        }
        self.tilemap = [            # Hér er teikna leikvöllinn.
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o],#1
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,x,x,o,o,o,o,o,o,o,o,o,x,x,x,x,x,o,x,x,x,x,x,x,o],#2
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,o,o,o,x,x,x,x,o,x,o,x,x,x,x,x,x,x,x,x,x,o],#3
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,o,o,o,x,o,o,x,o,x,o,x,o,o,x,x,o,x,x,x,x,o],#4
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,o,o,o,x,o,o,x,o,x,o,x,o,o,x,x,o,x,x,x,x,o],#5
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,o,o,o,x,o,o,x,x,x,o,x,x,x,x,x,o,o,o,x,x,o],#6
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,x,x,x,x,x,o,o,x,o,o,o,o,o,o,x,x,o,o,o,o,x,o],#7
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,o,o,x,x,x,x,x,x,x,x,x,x,x,x,x,o,x,x,x,x,o],#8
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,x,x,x,x,o,o,o,x,x,o,o,x,x,x,x,o,x,o,x,x,o],#9
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,x,o,o,x,x,x,o,x,o,o,o,o,o,o,o,o,x,x,o,o,o],#0
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,x,x,o,x,x,x,x,x,x,o,x,o,o,o,o,o,o,o,o,x,x,o,o,o],#1
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,x,x,o,o,o,o,o,o,o,o,x,o,o,x,x,x,x,x,x,x,x,x,x,o],#2
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,o,x,o,x,x,x,x,x,x,o,x,o,o,x,o,o,x,o,o,o,o,x,x,o],#3
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,x,x,o,o,o,o,o,x,x,o,x,o,o,x,o,o,x,o,o,x,x,x,x,o],#4
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,x,x,x,x,x,x,x,o,x,o,o,x,x,x,x,x,x,x,x,x,x,o],#5
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,x,x,x,o,o,o,o],#6
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,x,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,o],#7
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,o],#8
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,x,x,x,o,o,o,o,o,o,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,o],#9
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,x,x,o,x,x,x,x,x,x,o,x,x,x,x,x,o,x,x,x,x,x,x,x,x],#0
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,x,o,x,x,o,x,x,x,o,x,x,o,o,o,o,x,x,x,x,x,x,x,x],#1
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,w,w,x,x,o,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,x,x,x,o],#2
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,w,w,x,x,o,o,x,o,o,o,o,o,o,o,o,x,o,o,x,x,x,x,x,x,x,o],#3
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,x,o,x,x,x,x,x,x,x,x,o,o,x,x,x,x,x,x,x,o],#4
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,x,o,x,o,o,o,o,o,o,x,o,o,o,o,x,x,o,o,o,o],#5
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,o,o,x,o,x,x,o,o,o,o,o,o,o,o,x,x,x,x,x,o],#6
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,x,o,x,o,o,x,o,o,o,x,x,x,x,o,x,x,x,x,x,o],#7
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,x,x,x,x,o,x,o,o,x,x,x,o,x,o,o,x,x,x,x,o],#8
                    [o,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,g,o,o,o,o,o,x,x,x,x,x,x,x,x,x,x,x,o,o,x,x,x,x,x,x,x,o],#9
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o]#0
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7  8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3
                    ]
        self.Tilesize = 26          # Hér er skilgreint stærðina á hverri flíz
        self.Mapwidth = 53          # Þetta er fjöldi dálka á kortinu hér að ofan
        self.Mapheight= 30          # Þetta er fjöldi raða á kortinu hér að ofan
        self.RED=(255,0,0)          # Þetta er liturinn á kallinum
        #self.player_pos=[1345.5,513.5]
        self.player_pos=[1326.0,513.5]      # Þetta er upphafsstaðsetning leikmansins
        self.player_size=8                  # Þetta er stærð hans
        self.TORN2=False
    def run(self):
        Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize,0,0)   # Hér er kallað á classann frame í Kóðanum Generals.py
        Display_2 = Display_1.uppsetning()                                              # Hér er kallað á fallið í classanum frame

        game_over = False;                                                              # Game_over er = False þangað til leikurinn er X-aður eða ýtt er á K_ESCAPE
        pos = G.position(self.player_pos[0],self.player_pos[1],False,False,False,False) # pos býr yfir staðsetningu leikmansins
        #skor= G.skorddur(self.f1,self.f2,False,1326,513.5)
        teljari = 0
        while not game_over:



            pos          = G.position(self.player_pos[0],self.player_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)

            for event in pygame.event.get():
                G.Exit.exit(event)
                pos.true_not(event)
            #    skor.skordu(event,self.player_pos[0],self.player_pos[1])
            #skor.skordur2(self.player_pos[0],self.player_pos[1])
            if self.TORN2==True:
                Level4 = Level4class()
                Level4.run()
            xogy = pos.walk("constraintshluti1.txt","constraintshluti2.txt","empty.txt","empty.txt", True ) # Hér þarf skrá skorðurnar

            self.player_pos[0] = xogy[0]
            self.player_pos[1] = xogy[1]

            for row in range(self.Mapheight):         #ROÐ 1 UPPÍ 24

                for column in range(self.Mapwidth):   #DÁLKUR 1 UPPÍ 38
                    #pygame.draw.rect(  Surface  ,  color  ,  Rect  ,  Width  )
                    #  Surface => DISPLAYSURF2
                    #  Color   => self.colours[  self.tilemap[ röð ][ dalkur ]  ]
                    #  Rect    => ( Dálkur_i * Tilesize,  röð_j * Tilesize , Tilesize, Tilesize)
                    pygame.draw.rect(Display_2,   self.colours[self.tilemap[row][column]],   (column*self.Tilesize, row*self.Tilesize,self.Tilesize,self.Tilesize))
            #Teikna kassann
            pygame.draw.rect(Display_2, (191,158,42) , (self.player_pos[0],self.player_pos[1], self.player_size, self.player_size))


            # Kominn útur Hellinum
            ljos=G.birtan(self.player_pos[0],self.player_pos[1],Display_2,False)
            ljos.skuggi()
            if self.player_pos[0] <= 682.5:
                self.TORN2 = ljos.brightness()

            if teljari ==0:
                Display_2.blit(pygame.image.load('volund_texti.png'), (100,100))
                pygame.display.update()
                time.sleep(5)
                teljari = teljari + 1
            pygame.display.update()

def main():

    volun=Level3class()
    volun.run()
if __name__ == "__main__":
    main()
