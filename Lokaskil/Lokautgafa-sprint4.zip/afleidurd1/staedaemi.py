# Milliborð 2 vísar í þennan kóða
# Þessi kóði getur vísað í níu stærðfræðidæmi
import pygame
import Generals as G
pygame.init()
import sys
from Button import Takki
import math
import random
# Í staedaemi er hægt að velja mismunandi dæmi, Algebrudæmi, Afleiðudæmi og Heildunardæmi
# Ef valinn er flokkur þá fæst random dæmi, 3 dæmi er hægt að fá í hverjum flokk
from algebrad1 import algebradaemi1
from algebrad2 import algebradaemi2
from algebrad3 import algebradaemi3
from afleidurd1 import afleidurdaemi1
from afleidurd2 import afleidurdaemi2
from afleidurd3 import afleidurdaemi3
from heildund1 import heildundaemi1
from heildund2 import heildundaemi2
from heildund3 import heildundaemi3

bg = pygame.image.load('Staedaemi.png') # Þetta er aðalmyndin af Tom Cruise fljúgandi í tölvu


class levelinbetweenstae:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)
        self.teljarii=0
        self.button = Takki()           # svo að skjárinn mun ekki verða skrítinn þá var nauðsynlegt að setja þetta hér
    def randomalgebraproblem():
        a = random.randint(0,2)         # Random tala á bilinu 0 til 2
        algebra1 = algebradaemi1()      # a==0 þá fæst þetta dæmi
        algebra2 = algebradaemi2()      # a==1 þá fæst þetta dæmi
        algebra3 = algebradaemi3()      # a==2 þá fæst þetta dæmi
        if a == 0:
            algebra1.run()              # Hér er vísað í dæmið
        if a == 1:
            algebra2.run()              # Hér er vísað í dæmið
        if a == 2:
            algebra3.run()              # Hér er vísað í dæmið
    def randomafleiduproblem():
        a = random.randint(0,2)
        afleidur1 = afleidurdaemi1()    # a==0 þá fæst þetta dæmi
        afleidur2 = afleidurdaemi2()    # a==1 þá fæst þetta dæmi
        afleidur3 = afleidurdaemi3()    # a==2 þá fæst þetta dæmi
        if a == 0:
            afleidur1.run()              # Hér er vísað í dæmið
        if a == 1:
            afleidur2.run()              # Hér er vísað í dæmið
        if a == 2:
            afleidur3.run()              # Hér er vísað í dæmið
    def randomheildunproblem():
        a = random.randint(0,2)
        heildun1 = heildundaemi1()      # a==0 þá fæst þetta dæmi
        heildun2 = heildundaemi2()      # a==1 þá fæst þetta dæmi
        heildun3 = heildundaemi3()      # a==2 þá fæst þetta dæmi
        if a == 0:
            heildun1.run()              # Hér er vísað í dæmið
        if a == 1:
            heildun2.run()              # Hér er vísað í dæmið
        if a == 2:
            heildun3.run()              # Hér er vísað í dæmið


    def run(self):

        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150) # Hér er búin til hlutur. Vísað er í Kóðann Generals og klassann frame
        screen = screen1.uppsetning()                      # Hér er búin til ramminn
        game_over = False
        #button = Takki()

        while not game_over:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            #screen = screen1.uppsetning()

            screen.blit(bg,(0,0))
            # Hér eru búnir til þrír takkar fyrir Algebru, Heildun og Afleiður. Hægt er að velja hvað maður vill taka
            self.button.button("ALGEBRA", 140,380,150,40,self.WHITE,self.RED,levelinbetweenstae.randomalgebraproblem)
            self.button.button("HEILDUN",340,380,150,40,self.WHITE,self.RED,levelinbetweenstae.randomheildunproblem)
            self.button.button("AFLEIÐUR", 540,380,150,40,self.WHITE,self.RED,levelinbetweenstae.randomafleiduproblem)
            pygame.display.update()
            #button.button("ALGEBRA", 300,300, 20,40,self.RED,self.RED)

def main():
    game = levelinbetweenstae()
    game.run()

if __name__ == '__main__':
    main()
