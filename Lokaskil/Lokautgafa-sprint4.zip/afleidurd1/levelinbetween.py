import pygame
import sys
from Pong import Pong
import Generals as G

pygame.init()

bg = pygame.image.load('millibord.png')
bg = pygame.transform.scale(bg,(900,500))
Tomcruise = pygame.image.load('TomCruise.png') #Aðalpersónan
Johntravolta= pygame.image.load('JohnTravolta.png') #Persóna sem aðalpersóna talar við
textbox1= pygame.image.load('Text1level1.png') #textabúbla fyrir samtal við persónur
textbox2= pygame.image.load('text2level1.png')
textbox3= pygame.image.load('text3level1.png')
textbox4= pygame.image.load('text4level1.png')
textbox5= pygame.image.load('text5level1.png')

class LevelMilli:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (255,0,0)
        self.YELLOW = (255,255,0)
        self.player1_pos = [405, 203] #staðsetning aðalpersónu
        self.player1_size = 20      #stærð aðalpersónu
        self.player2_pos = [260,400] #staðsetning aukapersónu
        self.player2_size = 20      #Stærð aukapersónu
        self.textbox_pos = [300,250]    #Staðsetningin á textabúblu aðalpersónu
        self.textbox1_pos = [178,270]   #Staðsetningin á textabúblu aukapersónu
        self.sentencecount = 0  #Teljari sem telur hversu oft leikmaður ýtir á bil

    def communication(self, sentencecount):
        if sentencecount == 1: #Ef teljarinn er jafnt og 1 talar aukapersóna
            print("Setning 1: John Travolta segir ehv")
        elif sentencecount == 2:
            print("Setning 2: Tom Cruise segir ehv")
        elif sentencecount == 3:
            print("Setning 3: John Travolta segir ehv")
        elif sentencecount == 4:
            print("Setning 4: Tom Cruise segir ehv ")
        elif sentencecount == 5:
            print("Setning 5: John Travolta segir ehv ")
        elif sentencecount == 6:
            print("Setning 6: Tom Cruise segir ehv ")
        return


    def run(self):
        self.screen = pygame.display.set_mode((self.WIDTH,self.HEIGHT))
        pos = G.position(self.player1_pos[0],self.player1_pos[1],False,False,False,False) #Staðsetning leikmanns
        sentences = self.sentencecount

        game_over = False
        pong = Pong()
        while not game_over: #Á meðan while lykkjan er ekki False

            pos = G.position(self.player1_pos[0],self.player1_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)
            xogy = pos.walk("empty.txt","empty.txt","empty.txt","empty.txt",False)

            for event in pygame.event.get():
                G.Exit.exit(event)
                pos.true_not(event)

                if self.player1_pos[0] > 200 and self.player1_pos[0] < 550 and self.player1_pos[1] < 550 and self.player1_pos[1] > 150:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE: #Ef ýtt er á bil innan svæðis hækkar teljarinn
                            sentences   += 1
                if sentences == 7: #ef teljarinn er jafnt og 7 fer aðalpersóna í borð 1

                    pong.game_loop()


                print(self.player1_pos)

            self.player1_pos[0] = xogy[0]
            self.player1_pos[1] = xogy[1]

            #screen.fill((0,0,0))
            self.screen.blit(bg,(0,0))

            #communi = levelinbetween()
            #communi.communication(sentences)
            if sentences == 1:
                self.screen.blit(textbox1, (self.textbox_pos[0],self.textbox_pos[1]))  #Ef teljarinn er jafnt og 1 kemur fyrsta textabúblan
            elif sentences == 2:
                self.screen.blit(textbox2, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 3:
                self.screen.blit(textbox3, (self.textbox_pos[0],self.textbox_pos[1]))
            elif sentences == 4:
                self.screen.blit(textbox4, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 5:
                self.screen.blit(textbox5, (self.textbox_pos[0],self.textbox_pos[1]))

            self.screen.blit(Tomcruise, (self.player1_pos[0],self.player1_pos[1]))
            self.screen.blit(Johntravolta, (self.player2_pos[0],self.player2_pos[1]))

            pygame.display.update()


def main():
    game = LevelMilli()
    game.run()

if __name__ == '__main__':
    main()
