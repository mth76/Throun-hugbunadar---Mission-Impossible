# Þessi klassi er notaður Þegar gískað er á rétt svar.
# Eftirfarandi Kóðar vísa í hann
# afleidurd 1 2 og 3, algebrad 1 2 og 3, og heildund 1 2 og 3.
# Kóðinn vísar síðan í Kóðan levelinbetween3.
import pygame
import Generals as G
pygame.init()
import sys
from Button import Takki # Hér er verið að vísa í klassann takki sem er í kóðanum Button
from levelinbetween3 import LevelMilli3 #Hér er verið að vísa í klassann LevelMilli3 sem er í kóðanum levelinbetween3. Þetta er milli borð 3


bg = pygame.image.load('Rettsvar.png')     # Mynd
bg = pygame.transform.scale(bg,(799,500))


#staedaemi = staedaemi.levelinbetween()

class Good:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)
        self.button = Takki()           # svo að skjárinn mun ekki verða skrítinn þá var nauðsynlegt að setja þetta hér

    def run(self):
        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150) # Hér er búin til hlutur. Vísað er í Kóðann Generals og klassann frame
        screen = screen1.uppsetning()                      # Hér er búin til ramminn
        game_over = False
        levelinb3 = LevelMilli3()
        while not game_over:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()


            screen.blit(bg,(0,0))   # Hér er birt myndin 'Rettsvar.png'
            self.button.button("Halda áfram", 300,330,190,40,self.WHITE,self.RED,levelinb3.run)  # Hér er búin til takki til þess að fara í milliborð 3

            pygame.display.update()

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
