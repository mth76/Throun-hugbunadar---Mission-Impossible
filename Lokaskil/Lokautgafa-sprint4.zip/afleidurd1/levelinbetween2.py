# Kóðinn Pong vísar í þennan Kóða, þegar Pong leikurinn er unninn
# Þessi Kóði vísar síðan í leik 2 sem er Stærðfræðidæmið, Kóði: staedaemi.py

import pygame
import sys
import Generals as G
from staedaemi import levelinbetweenstae    # Í þennan Kóða er vísað í að lokum

pygame.init()

bg = pygame.image.load('Hallway3.png')              # Hér eru allar myndir sem eru í milliborðinu
bg = pygame.transform.scale(bg,(900,500))
Tomcruise = pygame.image.load('TomCruise.png')
Johntravolta= pygame.image.load('JohnTravolta.png')
DannyDevito = pygame.image.load('Danny_Devito.png')

textbox= pygame.image.load('text13.png')            # Hér eru allir textar sem kallarnir segja
textbox2= pygame.image.load('texti10.png')
textbox3 = pygame.image.load('text11.png')
textbox4 = pygame.image.load('text12.png')

class LevelMilli2:
    def __init__(self):
        self.WIDTH = 799            # Breidd skjásins
        self.HEIGHT = 500           # Hæð skjásins
        self.RED = (255,0,0)        # Ekki notað eins og er
        self.YELLOW = (255,255,0)       # Ekki notað eins og er, en þetta var stærð Tom Cruise þegar hann var kassi
        self.player1_pos = [405, 203]   # Staðsetning Tom Cruise
        self.player1_size = 20          # Ekki notað eins og er
        self.player2_pos = [130,300]    # Staðsetning John Travolta
        self.player2_size = 20          # Ekki notað eins og er
        self.player3_pos = [660,280]    # staðsetning Danny Devito
        self.textbox_pos = [60,140]     # Staðsetning texta
        self.textbox1_pos = [30,175]
        self.textbox2_pos = [570,120]
        self.textbox3_pos = [480,120]
        self.sentencecount = 0          # Þetta er notað þegar Textaboxinn poppa upp
        self.sentencecount2 = 0


    def communication(self, sentencecount,sentencecount2):      # Ekki lengur notað
        if self.sentencecount == 1 or sentencecount2 == 1:
            print("Setning 1: John Travolta segir ehv")
        elif self.sentencecount == 2 or self.sentencecount2 == 2:
            print("Setning 2: Tom Cruise segir ehv")
        elif self.sentencecount == 3 or self.sentencecount2== 3:
            print("Setning 3: John Travolta segir ehv")
        elif self.sentencecount == 4 or self.sentencecount2== 4:
            print("Setning 4: Tom Cruise segir ehv ")
        elif self.sentencecount == 5  or self.sentencecount2== 5:
            print("Setning 5: John Travolta segir ehv ")
        elif self.sentencecount == 6 or  self.sentencecount2== 6:
            print("Setning 6: Tom Cruise segir ehv ")
        return


    def run(self):
        self.screen = pygame.display.set_mode((self.WIDTH,self.HEIGHT)) # Hér er búin til skjárinn

        pos = G.position(self.player1_pos[0],self.player1_pos[1],False,False,False,False)   # Hér er búin til hlutur fyrir staðsetningu Tom Cruise
        sentences = self.sentencecount
        sentences2 = self.sentencecount
        game_over = False

        while not game_over:

            pos = G.position(self.player1_pos[0],self.player1_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)    # Hér er haldið utan um staðsetningu Tom Cruise
            xogy = pos.walk("empty.txt","empty.txt","empty.txt","empty.txt",False )                                     # Þetta fall lætur Tom Cruise laba

            for event in pygame.event.get():    # Exit Fall
                G.Exit.exit(event)
                pos.true_not(event)

                # Hér að neðan er kóði sem gerir manni kleift að tala við John Travolta
                if self.player1_pos[0] > 200  and self.player1_pos[0] < 400 and self.player1_pos[1] > 200 and self.player1_pos[1] < 500:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            sentences   += 1
                # Hér að neðan er kóði sem gerir manni kleift að tala við Danni Devito
                if self.player1_pos[0] > 400  and self.player1_pos[0] < 650 and self.player1_pos[1] > 200 and self.player1_pos[1] < 500:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            sentences2 += 1
                # Þegar maður hefur talað við Danny Devito 5 sinnum þá er vísað í þetta fall
                if sentences2 == 5:
                    stae =levelinbetweenstae()
                    stae.run()

            self.player1_pos[0] = xogy[0]
            self.player1_pos[1] = xogy[1]

            # Þetta birtir aðal skjáinn [umhverfið]
            self.screen.blit(bg,(0,0)) # bg = Hallway3.png

            # Hér poppa upp setningarnar þegar ýtt er a space
            if sentences == 1:
                self.screen.blit(textbox, (self.textbox_pos[0],self.textbox_pos[1]))
            if sentences2 == 1:
                self.screen.blit(textbox2, (self.textbox2_pos[0],self.textbox2_pos[1]))
            elif sentences2 == 2:
                self.screen.blit(textbox3, (self.textbox2_pos[0],self.textbox2_pos[1]))
            elif sentences2== 3:
                self.screen.blit(textbox4, (self.textbox2_pos[0],self.textbox2_pos[1]))

            self.screen.blit(Tomcruise, (self.player1_pos[0],self.player1_pos[1]))      # Hér eru myndir af Tom, john og danny
            self.screen.blit(Johntravolta, (self.player2_pos[0],self.player2_pos[1]))
            self.screen.blit(DannyDevito, (self.player3_pos[0],self.player3_pos[1]))

            pygame.display.update()


def main():
    game = LevelMilli2()
    game.run()

if __name__ == '__main__':
    main()
