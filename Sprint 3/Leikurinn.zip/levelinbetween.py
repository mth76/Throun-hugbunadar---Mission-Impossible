import pygame
import sys
import TestFrame
import Pong
pygame.init()
pong = Pong.Pong()
bg = pygame.image.load('millibord.png')
bg = pygame.transform.scale(bg,(900,500))
Tomcruise = pygame.image.load('TomCruise.png')
Johntravolta= pygame.image.load('JohnTravolta.png')
textbox1= pygame.image.load('Text1level1.png')
textbox2= pygame.image.load('text2level1.png')
textbox3= pygame.image.load('text3level1.png')
textbox4= pygame.image.load('text4level1.png')
textbox5= pygame.image.load('text5level1.png')

class position:
    def __init__(self,x,y,pr_left,pr_right,pr_up,pr_down):
        self.x = x
        self.y = y
        self.pr_left=  pr_left
        self.pr_right=pr_right
        self.pr_up  = pr_up
        self.pr_down= pr_down

    def true_not(self,event):
        pygame.init()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.pr_left = True
            if event.key == pygame.K_RIGHT:
                self.pr_right= True
            if event.key == pygame.K_UP:
                self.pr_up   = True
            if event.key == pygame.K_DOWN:
                self.pr_down = True

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.pr_left = False
            if event.key == pygame.K_RIGHT:
                self.pr_right = False
            if event.key == pygame.K_UP:
                self.pr_up   = False
            if event.key == pygame.K_DOWN:
                self.pr_down = False
    def walk(self):
        pygame.init()
        if self.pr_left:
            self.x -= 10
        if self.pr_right:
            self.x += 10
        if self.pr_up:
            self.y -= 10
        if self.pr_down:
            self.y += 10
        return [self.x,self.y]

class levelinbetween:
    def __init__(self):
        self.WIDTH = 900
        self.HEIGHT = 500
        self.RED = (255,0,0)
        self.YELLOW = (255,255,0)
        self.player1_pos = [405, 203]
        self.player1_size = 20
        self.player2_pos = [260,400]
        self.player2_size = 20
        self.textbox_pos = [300,250]
        self.textbox1_pos = [178,270]
        self.sentencecount = 0

    def communication(self, sentencecount):
        if sentencecount == 1:
            print("Setning 1: John Travolta segir ehv")
        elif sentencecount == 2:
            print("Setning 2: Tom Cruise segir ehv")
        elif sentencecount == 3:
            print("Setning 3: John Travolta segir ehv")
        elif sentencecount == 4:
            print("Setning 4: Tom Cruise segir ehv ")
        elif sentencecount == 5:
            print("Setning 5: John Travolta segir ehv ")
        elif sentencecount == 6:
            print("Setning 6: Tom Cruise segir ehv ")
        return


    def run(self):
        screen1 = TestFrame.frame(self.WIDTH, self.HEIGHT)
        screen = screen1.uppsetning()
        game_over = False
        pos = position(self.player1_pos[0],self.player1_pos[1],False,False,False,False)
        sentences = self.sentencecount

        while not game_over:

            pos = position(self.player1_pos[0],self.player1_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)
            xogy = pos.walk()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                pos.true_not(event)

                if self.player1_pos[0] < 375 and self.player1_pos[1] > 403:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            sentences   += 1
                if sentences == 7:
                    pong.game_loop()
                

                #print(self.player1_pos)

            self.player1_pos[0] = xogy[0]
            self.player1_pos[1] = xogy[1]

            #screen.fill((0,0,0))
            screen.blit(bg,(0,0))

            #communi = levelinbetween()
            #communi.communication(sentences)
            if sentences == 1:
                screen.blit(textbox1, (self.textbox_pos[0],self.textbox_pos[1]))
            elif sentences == 2:
                screen.blit(textbox2, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 3:
                screen.blit(textbox3, (self.textbox_pos[0],self.textbox_pos[1]))
            elif sentences == 4:
                screen.blit(textbox4, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 5:
                screen.blit(textbox5, (self.textbox_pos[0],self.textbox_pos[1]))


            screen.blit(Tomcruise, (self.player1_pos[0],self.player1_pos[1]))
            pygame.display.update()

            screen.blit(Johntravolta, (self.player2_pos[0],self.player2_pos[1]))
            pygame.display.update()


def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
