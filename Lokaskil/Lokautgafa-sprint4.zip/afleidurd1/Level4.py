import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *
import Generals as G
from GameOver import Game_Over

class Level4class():
    def __init__(self):


        Svartur = (0,  0,  0 )
        Dokkbr  = (58, 26, 12)
        white   = (33, 125, 34)
        green   = (33, 125, 34)
        wall    = (58, 62,  59)
        vidbaett= (180,180,180)


        o  = 0          # Wall
        x  = 1          # Floor
        b  = 2          # Water
        w  = 3
        v  = 4
        X  = 5

        self.colours = {            # Hér er verið að skilgreina o,x,g og w sem ákveðna liti
                    o : Svartur,
                    x : green,
                    b : Dokkbr,
                    w : white,
                    v : wall,
                    X : vidbaett
                        }
        self.tilemap = [
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    [b,b,b,b,b,w,w,w,w,w,w,w,w,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#1
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,X,x,x,x,X,x,x,x,x,x,x,v,v,v,v,x,x,b,b,b,b,b,b,b,b,b,b,b,b],#2
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,X,x,x,x,X,x,x,x,x,x,x,x,x,v,v,v,x,x,x,x,b,b,b,b,b,b,b,b,b,b,b],#3
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,v,x,X,v,v,v,v,v,v,v,v,v,x,x,x,v,v,x,x,v,v,x,v,v,v,b,b,b,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,v,v,x,x,v,x,x,b,b,b,b,b,b,b],#5
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,X,x,v,x,x,x,x,x,X,X,x,x,X,x,v,v,x,x,X,x,x,x,X,x,x,b,b,b,b,b,b,b],#6
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,X,x,x,x,x,x,v,v,x,x,x,v,x,X,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,X,v,x,v,x,x,x,x,X,x,X,x,x,x,x,x,v,x,X,x,x,x,x,x,b,b,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,v,x,v,x,x,v,x,v,v,v,v,v,x,x,x,x,X,X,x,x,v,x,x,b,b,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,x,v,x,x,x,X,x,v,x,x,X,x,x,v,x,x,x,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,X,x,v,v,v,v,v,x,v,x,v,v,x,x,x,x,X,x,x,v,x,v,x,x,b,b,b,b,b,b,b],#1
                    [b,b,b,b,b,b,b,X,X,X,x,b,b,b,b,b,b,b,b,b,v,v,x,x,x,x,x,x,v,x,v,x,v,v,x,x,v,v,x,x,v,x,x,x,x,X,x,b,b,b,b,b,b],#2
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,v,v,x,v,X,x,x,v,x,v,x,x,X,x,x,v,v,x,x,x,x,x,v,x,x,x,b,b,b,b,b,b],#3
                    [b,b,b,b,b,b,b,x,X,X,X,b,b,b,b,b,b,v,v,v,v,x,x,x,x,x,x,x,v,x,v,v,x,x,x,x,X,x,x,X,X,x,x,x,x,x,x,x,b,b,b,b,b],#4
                    [b,b,b,b,b,b,b,x,X,x,x,b,b,b,b,b,b,v,x,x,x,x,x,v,X,x,X,x,v,x,x,v,x,x,x,X,x,x,X,v,x,x,v,v,x,x,x,x,b,b,b,b,b],#5
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,v,x,x,x,x,x,x,v,x,x,v,X,X,x,v,v,x,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#6
                    [b,b,b,b,b,b,b,X,X,X,x,b,b,b,b,b,b,v,x,x,x,x,X,v,v,v,v,v,v,x,X,X,X,x,x,x,v,X,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#7
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,x,x,x,x,x,X,v,x,x,x,v,x,x,v,x,v,x,v,x,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,X,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,X,x,x,X,X,x,x,x,x,v,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,v,x,v,v,v,v,v,v,x,X,x,X,X,x,X,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,X,X,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,v,v,v,x,x,x,x,X,x,x,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#1
                    [b,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b,b,v,v,v,v,x,v,x,x,x,x,x,v,x,x,x,X,x,x,x,v,v,v,v,v,x,v,x,x,x,x,x,o,b,b,b,b],#2
                    [b,x,x,x,x,v,x,X,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,x,x,x,X,x,v,x,x,x,x,x,v,x,x,x,x,x,o,b,b,b,b],#3
                    [b,x,x,v,v,x,x,x,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,X,x,x,X,x,v,x,x,x,x,x,v,x,v,x,x,x,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,v,x,x,b,b,x,x,x,x,v,v,v,x,x,x,x,x,v,v,v,v,v,v,v,v,v,x,x,x,x,x,v,v,v,v,v,v,b,b,b,b,b],#5
                    [b,x,x,x,v,v,v,v,v,v,v,v,x,x,x,x,b,x,x,X,x,x,v,v,x,x,x,x,x,x,x,x,x,x,X,x,v,x,v,x,x,x,v,x,x,x,x,b,b,b,b,b,b],#6
                    [b,x,x,X,x,x,x,x,x,x,x,v,X,x,x,x,b,b,x,x,x,x,x,v,v,x,x,x,x,x,x,v,X,x,x,x,v,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,b,x,x,x,x,x,x,x,x,x,x,x,b,b,b,x,x,x,x,X,v,v,v,X,v,v,v,x,X,x,x,v,x,v,v,v,v,v,x,x,b,b,b,b,b,b,b,b],#8
                    [b,x,x,x,x,x,x,x,b,x,x,x,x,x,x,x,x,b,b,b,b,b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#0
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    ]
        self.Tilesize = 26
        self.Mapwidth = 53
        self.Mapheight= 30
        self.RED=(255,0,0)
        #self.player_pos=[1345.5,513.5]
        self.player_pos=[1274.0-13*2,546.0+13]
        self.player_size=8
        self.yfir=False
        self.einusinni1 =1
        self.tala=0
        self.einusinni2 =1
        self.eltingarfylki=0
        self.Health = 3

    def run(self):
        Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize,0,0)   # Hér er kallað á classann frame í Kóðanum Generals.py
        Display_2 = Display_1.uppsetning()
        font = pygame.font.Font("freesansbold.ttf", 25)
        # Hér er kallað á fallið í classanum fram
        game_over = False;                                                              # Game_over er = False þangað til leikurinn er X-aður eða ýtt er á K_ESCAPE
        pos = G.position(self.player_pos[0],self.player_pos[1],False,False,False,False) # pos býr yfir staðsetningu leikmansins
        while not game_over:


            output_string = "Líf eftir: {}".format(int(self.Health))
            text = font.render(output_string, True, [255,255,255])
            Display_2.blit(text, [300, 220])
            pygame.display.flip()
            Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize,0,0)
            pos       = G.position(self.player_pos[0],self.player_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)

            for event in pygame.event.get():
                G.Exit.exit(event)
                pos.true_not(event)                                             # Þetta fall lætur takkana vera true eða false


            x = self.player_pos[0]; y = self.player_pos[1];
            xogy = pos.walk("skordur1.txt","skordur2.txt","skordur3.txt","skordur4.txt",True)
            self.player_pos[0] = xogy[0]
            self.player_pos[1] = xogy[1]
            print(self.player_pos[0],self.player_pos[1])
            #if self.player_pos[0] >1170.0 or self.player_pos[0] <1241.5 and self.player_pos[1] ==617.5:
                #self.player_pos[1]-=1

            #pygame.draw.rect(Display_2, self.RED, (x,y, self.player_size,self.player_size))

            #if self.player_pos[1]==383.5:
                #x=JohnTravolta()
                #x.hallo(Display_2)
            for row in range(self.Mapheight):         #ROÐ 1 UPPÍ 24

                for column in range(self.Mapwidth):   #DÁLKUR 1 UPPÍ 38
                    #pygame.draw.rect(  Surface  ,  color  ,  Rect  ,  Width  )
                    #  Surface => DISPLAYSURF2
                    #  Color   => self.colours[  self.tilemap[ röð ][ dalkur ]  ]
                    #  Rect    => ( Dálkur_i * Tilesize,  röð_j * Tilesize , Tilesize, Tilesize)
                    pygame.draw.rect(Display_2,   self.colours[self.tilemap[row][column]],   (column*self.Tilesize, row*self.Tilesize,self.Tilesize,self.Tilesize))
            #Teikna kassann


            if self.player_pos[1]==383.5 and self.einusinni1==1:    #Þetta er keyrt einu sinni. Ég vill ekki keyra classan oftar en einu sinni
                John=G.JohnTravolta()
                self.yfir=True
                self.einusinni1=self.einusinni1+1
                upph_x=self.player_pos[0]
                upph_y=self.player_pos[1]
            if self.yfir==True:
                John.hallo(Display_2)
                if self.einusinni2==1:
                    John.einusinni(Display_2,self.player_pos[0],self.player_pos[1],self.Mapwidth,self.Mapheight,self.colours,self.tilemap,self.Tilesize)
                    self.einusinni2=self.einusinni2+1
                    Elta1=True
                    Elta2=False
                    pygame.display.update()
                    time.sleep(2)
                if Elta1:
                    John.eltingarleikur1(Display_2,upph_x,upph_y)
                    Elta1=John.leikur1buin(upph_x,upph_y)
                    John.fylki(self.player_pos[0],self.player_pos[1])
                    if Elta1==False:
                        Elta2=True
                if Elta2:
                    John.eltingarleikur2(Display_2,self.player_pos[0],self.player_pos[1])
                    self.yfir=John.TorF
                    print(self.yfir)
                    if self.yfir==False:
                        self.einusinni1=1
                        self.einusinni2=1
                        self.player_pos=[1274.0-13*2,546.0+13]
                        self.Health-=1

                        if self.Health==1 or self.Health==2:
                            Display_2.blit(pygame.image.load('thu_tapadir.png'), (340,250))
                            pygame.display.update()
                            time.sleep(3.5)
                        if self.Health==0:
                            Display_2.blit(pygame.image.load('thu_tapadir_alveg.png'), (340,250))
                            pygame.display.update()
                            time.sleep(5)
                            game = Game_Over()
                            game.over()
                        John.Playagain()
                    John.fylki(self.player_pos[0],self.player_pos[1])

                if y<=-20:
                    Display_2.blit(pygame.image.load('thu_vannst.png'), (340,250))
                    pygame.display.update()
                    time.sleep(5)
                    Display_3 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize,200,150)   # Hér er kallað á classann frame í Kóðanum Generals.py
                    Display_4 = Display_3.uppsetning()
                    self.einusinni1=1
                    self.einusinni2=1
                    self.player_pos=[1274.0-13*2,546.0+13]
                    self.Health=3
                    self.yfir=False
                    import Menu
                    menu = Menu.Menu()
                    menu.game_intro()

        #    pygame.draw.circle(Display_2, [0,0,0],             [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1020,600)
            #birta=G.birtan(self.player_pos[0],self.player_pos[1],Display_2,True)
            #birta.skuggi()
            pygame.draw.rect(Display_2, (85,77,0), (self.player_pos[0],self.player_pos[1], self.player_size, self.player_size))
            # Kominn útur Hellinum
            time.sleep(0.02)
def main():
    John=G.JohnTravolta()
    John.Playagain()
if __name__ == "__main__":
    main()
