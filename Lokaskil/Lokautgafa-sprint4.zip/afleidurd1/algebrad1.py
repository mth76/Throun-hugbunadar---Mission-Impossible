import pygame
import Generals as G
pygame.init()
import sys
from Button import Takki
from goodanswer import Good
from wronganswer import Wrong

bg = pygame.image.load('algebrad1.png')
bg = pygame.transform.scale(bg,(799,500))
button = Takki()



class algebradaemi1:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)
        self.button = Takki()
    def wronganswer():
        wronganswer = Wrong()
        wronganswer.run()
    def goodanswer():
        goodanswer = Good()
        goodanswer.run()

    def run(self):
        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150)
        screen = screen1.uppsetning()
        game_over = False
        while not game_over:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            screen.blit(bg,(0,0))

            self.button.button1(64,393,191,65,algebradaemi1.wronganswer)
            self.button.button1(326,393,174,65,algebradaemi1.wronganswer)
            self.button.button1(578,393,174,65,algebradaemi1.goodanswer)
            #screen.blit(bg,(0,0))
            pygame.display.update()
            #button.button("ALGEBRA", 300,300, 20,40,self.RED,self.RED)

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
