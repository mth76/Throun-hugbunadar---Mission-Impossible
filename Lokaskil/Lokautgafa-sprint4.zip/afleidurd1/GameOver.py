import pygame
from Button import Takki
import Generals as G
class Game_Over:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500

        self.clock = pygame.time.Clock()
        self.bakgrunnur = pygame.image.load('gameover.png')
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)

    def image(self,background,x,y):
        self.screen.blit(background,(x,y))

    def over(self):
        button = Takki()
        self.screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150) # Hér er búin til hlutur. Vísað er í Kóðann Generals og klassann frame
        self.screen = self.screen1.uppsetning()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            self.screen.fill(self.WHITE)
            self.image(self.bakgrunnur,0,0)
            button.button('Hætta',500,350,200,50,self.RED,self.BRIGHT_RED,pygame.quit)
            button.button('Spila',200,350,200,50,self.GREEN,self.BRIGHT_GREEN)
            self.mouse = pygame.mouse.get_pos()
            self.click = pygame.mouse.get_pressed()
            if 200+ 200 > self.mouse[0] > 200 and 350 + 50> self.mouse[1] >50:
                if self.click[0] == 1:
                    import Menu
                    menu = Menu.Menu()
                    menu.game_intro()

            pygame.display.update()
            self.clock.tick(15)
