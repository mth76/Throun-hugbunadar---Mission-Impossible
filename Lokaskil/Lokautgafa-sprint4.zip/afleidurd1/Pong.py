import pygame
import random
import sys
from levelinbetween2 import LevelMilli2
from GameOver import Game_Over
import Generals as G


class Paddle(pygame.Rect):
    def __init__(self, velocity, up_key,down_key, *args, **kwargs):
        self.velocity = velocity #skilgreini hraða spaðans
        self.up_key = up_key #skilgreinum takka
        self.down_key = down_key
        super().__init__(*args, **kwargs)

    def move_paddle(self, board_height):
        keys_pressed = pygame.key.get_pressed()

        if keys_pressed[self.up_key]: #Ef upp takki er ýttur hreyfist spaðinn upp
            if self.y - self.velocity > 0:
                self.y -= self.velocity

        if keys_pressed[self.down_key]: #Ef niður takki er ýttur hreyfist spaðinn niður
            if self.y + self.velocity < board_height - self.height:
                self.y += self.velocity


class Ball(pygame.Rect):

    def __init__(self, velocity, *args, **kwargs):
        self.velocity = velocity #Skilgreini hraða boltans
        self.angle = 0 #Upphafstaðsetning boltans
        super().__init__(*args, **kwargs)

    def move_ball(self): #Hreyfing boltans
        self.x += self.velocity
        self.y += self.angle


class Pong:
    WIDTH = 799 #Breidd skjás
    HEIGHT = 500 #Hæð skjás
    PADDLE_WIDTH = 10 #Breidd spaða
    PADDLE_HEIGHT = 50 #Hæð spaða
    BALL_WIDTH = 10 #Breidd boltans
    BALL_VELOCITY = 10 #Hraði boltans
    WALL_HEIGHT = 2000 #Stærð veggsins


    AQUA   = (0 ,128 ,128  ) #Litir
    WHITE  = (255,255,255)
    ORANGE = (255, 165,0)
    YELLOW = (255, 255, 0)
    def __init__(self):
        pygame.init()

        self.screen=pygame.display.set_mode((self.WIDTH,self.HEIGHT))
        self.clock = pygame.time.Clock()

        self.paddles = [] #Listi sem inniheldur hraða, breidd og hæð spaðans
        self.balls = []  #Listi sem inniheldur hraða, breidd og hæð boltans
        self.paddles.append(Paddle(
            self.BALL_VELOCITY,
            pygame.K_w,
            pygame.K_s,
            0,
            0,
            self.PADDLE_WIDTH,
            self.WALL_HEIGHT
        ))

        self.paddles.append(Paddle(  # The right paddle
            self.BALL_VELOCITY,
            pygame.K_UP,
            pygame.K_DOWN,
            self.WIDTH - self.PADDLE_WIDTH,
            self.HEIGHT / 2 - self.PADDLE_HEIGHT / 2,
            self.PADDLE_WIDTH,
            self.PADDLE_HEIGHT
        ))

        self.balls.append(Ball( #The wall
            self.BALL_VELOCITY,
            self.WIDTH / 2 - self.BALL_WIDTH / 2,
            self.HEIGHT / 2 - self.BALL_WIDTH / 2,
            self.BALL_WIDTH,
            self.BALL_WIDTH
        ))
    def move_to_middle(self): #Ef leikmaður missir líf færist boltinn aftur á miðjuna
        for ball in self.balls:
            ball.x = 10
            ball.y = self.HEIGHT /2
            pygame.time.delay(1000)



    def check_bounce_off_wall(self): #Fall sem tjékkar hvort boltinn skoppaði af vegg og breytur um stefnu boltans
        for ball in self.balls:
            if ball.x > self.WIDTH or ball.x < 0:
                self.life-=1
                self.move_to_middle()
            if ball.y > self.HEIGHT - self.BALL_WIDTH or ball.y < 0:
                ball.angle = -ball.angle

    def check_bounce_off_paddle(self): #Fall sem tjékkar hvort boltinn skoppaði af spaðanum
        for ball in self.balls:
            for paddle in self.paddles:
                if ball.colliderect(paddle):
                    ball.velocity = -ball.velocity
                    ball.angle = random.randint(-10, 10)
                    break


    def game_loop(self):
        self.life = 3 #Líf leikmanns í borði 1
        counter = 0
        clock = pygame.time.Clock()
        font = pygame.font.Font("freesansbold.ttf", 25)
        frame_count = 0
        frame_rate = 60
        start_time = 10 #Tími í leiknum
        size = [self.WIDTH,500] #Stærð skjás
        screen = pygame.display.set_mode(size)
        game =Game_Over()
        level =LevelMilli2()
        while True:
            for event in pygame.event.get():
                G.Exit.exit(event)

            # Teikna skjáinn
            self.screen.fill((0, 0, 0))

            for paddle in self.paddles:
                paddle.move_paddle(self.HEIGHT)
                pygame.draw.rect(self.screen, self.WHITE, paddle)




            for ball in self.balls:
                ball.move_ball()
                pygame.draw.rect(self.screen, self.ORANGE, ball)

            self.check_bounce_off_wall()
            self.check_bounce_off_paddle()


            total_seconds = frame_count // frame_rate

            minutes = total_seconds // 60

            seconds = total_seconds % 60

            total_seconds = start_time - (frame_count // frame_rate)

            if total_seconds ==0: #Ef það eru núll sékundur eftir hækkar counterinn
                counter +=1
            seconds = total_seconds % 60
            level =LevelMilli2()
            if counter == 1: #Ef counterinn er jafnt og 1 köllum  við á næsta milliborð
                level.run()


            if self.life == 0: #Ef líf leikmanns er jafnt og núll þá köllum við á game over fallið
                game.over()
                pygame.time.sleep(5)



            output_string = "Tími Eftir: {0:02}".format(seconds) #Texti sem sést efst í borðinu sem sýnir hvað er mikill tími eftir

            text = font.render(output_string, True, self.ORANGE)
            screen.blit(text, [400, 15])

            life_string = "Líf Eftir: {}".format(self.life) #Texti sem sést efst í borðinu sem sýnir hvað leikmaður á mörg líf eftir
            text_life = font.render(life_string,True,self.ORANGE)
            screen.blit(text_life, [600,15])

            frame_count += 1

            clock.tick(frame_rate)


            pygame.display.flip()
            self.clock.tick(60)



if __name__=='__main__':
    pong = Pong()
    pong.game_loop()
