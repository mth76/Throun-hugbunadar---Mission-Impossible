import pygame
import Generals as G
pygame.init()
import sys
from Button import Takki
from goodanswer import Good
from wronganswer import Wrong

bg = pygame.image.load('afleidurd1.png')
#Eitt af þremur afleiðudæmum sem hægt er að fá í borði 2#



class afleidurdaemi1:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)
        self.button = Takki()

    def wronganswer():
        try:
            self.wronganswer = Wrong()
        except:
            pass

        self.wronganswer.run()
    def goodanswer():
        self.goodanswer = Good()
        self.goodanswer.run()

    def run(self):
        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150)
        screen = screen1.uppsetning()
        game_over = False
        while not game_over:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            screen.blit(bg,(0,0))

            self.button.button1(30,373,246,65, afleidurdaemi1.wronganswer)
            self.button.button1(318,373,219,65, afleidurdaemi1.goodanswer)
            self.button.button1(592,373,185,65, afleidurdaemi1.wronganswer)

            pygame.display.update()

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
