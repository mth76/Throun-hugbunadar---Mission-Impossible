import pygame, os
from Button import Takki
from levelinbetween import LevelMilli
import Generals as G
pygame.init()


class Controls:
    def __init__(self):
        self.WIDTH  = 799
        self.HEIGHT = 500
        self.screen=pygame.display.set_mode((self.WIDTH,self.HEIGHT))
        self.clock = pygame.time.Clock()
        self.mynd = pygame.image.load('Scientology.jpg')
        self.saga = pygame.image.load('Leidbeiningar.png')
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)

    def image(self,background,x,y):
        self.screen.blit(background,(x,y))

    def leid(self):
        button =Takki()
        level =LevelMilli()
        while True:
            for event in pygame.event.get():
                G.Exit.exit(event)

            self.screen.fill(self.WHITE)
            self.image(self.mynd,0,0)
            self.image(self.saga,40,250)
            button.button('Hætta',659,300,125,50,self.GOLD,self.BRIGHT_GOLD,pygame.quit)
            button.button('Spila',515,300,125,50,self.RED,self.BRIGHT_RED,level.run)
            pygame.display.update()
            self.clock.tick(15)
