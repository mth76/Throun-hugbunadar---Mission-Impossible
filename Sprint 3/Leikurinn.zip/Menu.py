import pygame
import os
import PongM
import SoguthradurKlass
import Button

import levelinbetween

storyKlasi = SoguthradurKlass.Soguthradur()
button = Button.Button()
level = levelinbetween.levelinbetween()
pygame.init()
class Menu:
    def __init__(self):
        self.WIDTH = 900
        self.HEIGHT = 500
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)
        pygame.init()
        pygame.font.init()
        self.screen=pygame.display.set_mode((self.WIDTH,self.HEIGHT))
        pygame.display.set_caption("Mission Impossible")
        self.clock = pygame.time.Clock()
        self.background = pygame.image.load('Mission.jpg')

    def game_intro(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            self.screen.fill((0, 0, 0))
            self.screen.fill(self.WHITE)
            storyKlasi.image(self.background,0,0)


            button.button('Söguþráður',175,350,150,75,self.RED,self.BRIGHT_RED,storyKlasi.story)
            button.button('Spila',375,350,150,75,self.GREEN,self.BRIGHT_GREEN,level.run)
            button.button('Hætta',575,350,150,75,self.GOLD,self.BRIGHT_GOLD,pygame.quit)

            pygame.display.update()
            self.clock.tick(15)
menu = Menu()
menu.game_intro()
pygame.quit()
quit()
