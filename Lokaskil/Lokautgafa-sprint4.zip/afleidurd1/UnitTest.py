import unittest
import Menu
import levelinbetween
import levelinbetween2
import levelinbetween3
import Pong
import Level3
import Level4
class TestStrings(unittest.TestCase):
    def setUp(self):
        self.menu = Menu.Menu()
        self.milli = levelinbetween.LevelMilli()
        self.bord1 = Pong.Pong()
        self.milli2 = levelinbetween2.LevelMilli2()
        self.milli3 = levelinbetween3.LevelMilli3()
        self.level3 = Level3.Level3class()
        self.level3 = Level3.Level4class()

    def test_isinstance(self):
        self.assertIsInstance(self.menu, Menu.Menu)
        self.assertIsInstance(self.milli, levelinbetween.LevelMilli)
        self.assertIsInstance(self.bord1,Pong.Pong)
        self.assertIsInstance(self.milli2, levelinbetween2.LevelMilli2)
        self.assertIsInstance(self.milli3, levelinbetween3.LevelMilli3)
        self.assertIsInstance(self.level3,Level3.Level3class)
        self.assertIsInstance(self.level4,Level3.Level4class)

    def test_IsNone(self):
        self.assertIsNone(self.menu.game_intro())
        self.assertIsNone(self.milli.run())


if __name__ == '__main__':
    unittest.main()
