import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *

class frame:
    def __init__(self,x1,y1):
        self.x=x1
        self.y=y1
    def uppsetning(self):
        os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (-500,0)
        pygame.init()
        DISPLAYSURF = pygame.display.set_mode((self.x,self.y))
        pygame.FULLSCREEN
        print('Hallo')
        

        return DISPLAYSURF


#Þessi kóði er inní aðal-forlykkjunni og er því keyrður aftur og aftur
#Hann breytir staðsetningu x og y. Það sem hefur áhrif á outputtið Hermun
#   KEYUP og KEYDOWN
class position:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.pr_left= False
        self.pr_right=False
        self.pr_up  = False
        self.pr_down= False

    def true_not(self,event):
        pygame.init()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.pr_left = True
            if event.key == pygame.K_RIGHT:
                self.pr_right= True
            if event.key == pygame.K_UP:
                self.pr_up   = True
            if event.key == pygame.K_DOWN:
                self.pr_down = True

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.pr_left = False
            if event.key == pygame.K_RIGHT:
                self.pr_right = False
            if event.key == pygame.K_UP:
                self.pr_up   = False
            if event.key == pygame.K_DOWN:
                self.pr_down = False
    def walk(self):
        pygame.init()
        if self.pr_left:
            self.x -=(13/2)
        if self.pr_right:
            self.x +=(13/2)
        if self.pr_up:
            self.y -=(13/2)
        if self.pr_down:
            self.y +=(13/2)
        #Hér mun ég kalla á Walkbackfallið og athuga hvort ég er að labba á vegg
        #player_pos = walkback(self.x,self.y)
        return [self.x,self.y]

    def Walkback(self,file1,file2,file3):
        pass;
        #return player_pos()
class maze():
    def __init__(self):

        Svartur = (0,  0,  0 )
        Dokkbr  = (58, 26, 12)
        Blue    = (0,  0,  255)
        self.Black  = (0, 0, 0)

        #self.skrif = open("constraintshluti1.txt", 'a')
        o  = 0          # Wall
        x =  1          # Floor
        b  = 2          # Water
        s  = 3

        self.colours = {
                    o : Svartur,
                    x : Dokkbr,
                    b : Blue,
                    s : self.Black
                  }
        self.tilemap = [
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o],#1
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,o,o,o,o,o,o,o,o,x,x,x,x,x,o,x,x,x,x,x,x,o],#2
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,o,o,o,x,x,x,x,o,x,o,x,x,x,x,x,x,x,x,x,x,o],#3
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,o,o,o,x,o,o,x,o,x,o,x,o,o,x,x,o,x,x,x,x,o],#4
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,o,o,o,x,o,o,x,o,x,o,x,o,o,x,x,o,x,x,x,x,o],#5
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,o,o,o,x,o,o,x,x,x,o,x,x,x,x,x,o,o,o,x,x,o],#6
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,x,x,x,x,x,o,o,x,o,o,o,o,o,o,x,x,o,o,o,o,x,o],#7
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,o,o,x,x,x,x,x,x,x,x,x,x,x,x,x,o,x,x,x,x,o],#8
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,x,x,x,x,o,o,o,x,x,o,o,x,x,x,x,o,x,o,x,x,o],#9
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,x,o,o,x,x,x,o,x,o,o,o,o,o,o,o,o,x,x,o,o,o],#0
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,x,x,x,x,x,x,o,x,o,o,o,o,o,o,o,o,x,x,o,o,o],#1
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,o,o,o,o,o,o,o,x,o,o,x,x,x,x,x,x,x,x,x,x,o],#2
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,o,x,x,x,x,x,x,o,x,o,o,x,o,o,x,o,o,o,o,x,x,o],#3
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,o,o,o,o,x,x,o,x,o,o,x,o,o,x,o,o,x,x,x,x,o],#4
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,o,x,o,o,x,x,x,x,x,x,x,x,x,x,o],#5
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,x,x,x,o,o,o,o],#6
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,o],#7
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,o],#8
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,o,o,o,o,o,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,o],#9
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,o,x,x,x,x,x,x,o,x,x,x,x,x,o,x,x,x,x,x,x,x,o],#0
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,o,x,x,o,x,x,x,o,x,x,o,o,o,o,x,x,x,x,x,x,x,o],#1
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,x,x,x,x,x,x,x,x,x,o,x,x,x,x,x,x,x,x,x,x,o],#2
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,o,o,x,o,o,o,o,o,o,o,o,x,o,o,x,x,x,x,x,x,x,o],#3
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,b,b,b,x,x,o,o,o,x,x,o,x,x,x,x,x,x,x,x,o,o,x,x,x,x,x,x,x,o],#4
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,b,o,b,x,o,o,o,o,x,x,o,x,o,o,o,o,o,o,x,o,o,o,o,x,x,o,o,o,o],#5
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,b,b,o,o,o,o,o,x,o,o,x,o,x,x,o,o,o,o,o,o,o,o,x,x,x,x,x,o],#6
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,b,b,b,o,o,o,o,o,x,x,o,x,o,o,x,o,o,o,x,x,x,x,o,x,x,x,x,x,o],#7
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,o,x,o,o,x,x,x,o,x,o,o,x,x,x,x,o],#8
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,x,x,x,x,x,x,x,x,x,x,x,o,o,x,x,x,x,x,x,x,o],#9
                    [o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o,o]#0
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3
                    ]
        self.Tilesize = 26
        self.Mapwidth = 53
        self.Mapheight= 30

        pygame.init()
        self.RED=(255,0,0)
        self.player_pos=[53*26-13*5,30*26-13*5]
        self.player_size=8

    def run(self,file,file2,file3):
        #   self.mapwidth*self.Tilesize,  self.Mapheight*self.Tilesize
        DISPLAYSURF1 = frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize)
        DISPLAYSURF2=DISPLAYSURF1.uppsetning()

        #óþarfi nema þegar verið er að skrifa í gagnasafn
        #x_hnit=747.5
        #y_hnit=403
        game_over = False;
        while not game_over:
            pos = position(self.player_pos[0],self.player_pos[1])
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
##
                pos.true_not(event)

            xogy =  pos.walk()
            self.player_pos[0]=xogy[0]
            self.player_pos[1]=xogy[1]
            #framey= _ini
            if DISPLAYSURF1.y >= 403:
                f = open(file, 'r');
                #print(x,y)
                texti = str(DISPLAYSURF1.x)+','+str(DISPLAYSURF1.y)+'\n';
                #print(texti)
                #print(texti)

                for line in f.readlines():
                    if texti == line:
                        if pr_left:
                            self.player_pos[0] +=(13/2)
                        if pr_right:
                            self.player_pos[0] -=(13/2)
                        if pr_up:
                            self.player_pos[1] +=(13/2)
                        if pr_down:
                            self.player_pos[1] -=(13/2)

            else:
                f = open(file2, 'r');
                #print(x,y)
                texti = str(x)+','+str(y)+'\n';
                #print(texti)
                #print(texti)

                for line in f.readlines():

                    if texti == line:
                        if pr_left:
                            self.player_pos[0] +=(13/2)
                        if pr_right:
                            self.player_pos[0] -=(13/2)
                        if pr_up:
                            self.player_pos[1] +=(13/2)
                        if pr_down:
                            self.player_pos[1] -=(13/2)
            self.player_pos=[self.player_pos[0],self.player_pos[1]]
            pygame.init()

            for row in range(self.Mapheight):         #ROÐ 1 UPPÍ 24

                for column in range(self.Mapwidth):   #DÁLKUR 1 UPPÍ 38

                    #pygame.draw.rect(  Surface  ,  color  ,  Rect  ,  Width  )
                    #  Surface => DISPLAYSURF2
                    #  Color   => self.colours[  self.tilemap[ röð ][ dalkur ]  ]
                    #  Rect    => ( Dálkur_i * Tilesize,  röð_j * Tilesize , Tilesize, Tilesize)
                    pygame.draw.rect(DISPLAYSURF2,   self.colours[self.tilemap[row][column]],   (column*self.Tilesize, row*self.Tilesize,self.Tilesize,self.Tilesize))
            #Teikna kassann
            pygame.draw.rect(DISPLAYSURF2, self.RED, (self.player_pos[0],self.player_pos[1], self.player_size, self.player_size))
            if self.player_pos[0] >= 682.5:
                pygame.draw.circle(DISPLAYSURF2, [0,0,0], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520,1480)
            elif self.player_pos[0] <682.5-6.25 and x>=682.5-6.25*2:
                pygame.draw.circle(DISPLAYSURF2, [51,51,51], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.05)
            elif self.player_pos[0] <682.5-6.25*2 and x>=682.5-6.25*3:
                pygame.draw.circle(DISPLAYSURF2, [76.5,76.5,76.5], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.08)
            elif self.player_pos[0] <682.5-6.25*3 and x>=682.5-6.25*4:
                pygame.draw.circle(DISPLAYSURF2, [102,102,102], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.095)
            elif self.player_pos[0] <682.5-6.25*4 and x>=682.5-6.25*5:
                pygame.draw.circle(DISPLAYSURF2, [127.5,127.5,127.5], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.1)
            elif self.player_pos[0] <682.5-6.25*5 and x>=682.5-6.25*6:
                pygame.draw.circle(DISPLAYSURF2, [153,153,153], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.115)
            elif self.player_pos[0] <682.5-6.25*6 and x>=682.5-6.25*7:
                pygame.draw.circle(DISPLAYSURF2, [179,179,179], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.134)
            elif self.player_pos[0] <682.5-6.25*7 and x>=682.5-6.25*8:
                pygame.draw.circle(DISPLAYSURF2, [205,205,205], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.15)
            elif self.player_pos[0] <682.5-6.25*8 and x>=682.5-6.25*9:
                pygame.draw.circle(DISPLAYSURF2, [230,230,230], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(0.2)
            elif self.player_pos[0] <682.5-6.25*9 and x>=682.5-6.25*10:
                pygame.draw.circle(DISPLAYSURF2, [255,255,255], [int(self.player_pos[0])+5,int(self.player_pos[1]) +5], 1520)
                time.sleep(1.2)
            pygame.display.update()

def main():
    filename1="constraintshluti1.txt"
    filename2="constraintshluti2.txt"
    filename3="tefjari.txt"
    volun=maze()
    volun.run(filename1,filename2,filename3)
if __name__ == "__main__":
    main()
