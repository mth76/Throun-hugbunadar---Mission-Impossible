# Stærðfræðidæmin níu vísa í þennan kóða ef valið er rangt svar
# Þá er aftur vísað í fallið staedaemi.run()
import pygame
import Generals as G    # Kóðinn Generals Vísar í fallið frame sem býrt til display-ið
pygame.init()
import sys
from Button import Takki
#from staedaemi import levelinbetweenstae

bg = pygame.image.load('Reynduaftur.png')   # Mynd sem hefur textann að rangt svar var valið
bg = pygame.transform.scale(bg,(799,500))



#staedaemi = staedaemi.levelinbetween()

class Wrong:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)
        self.button = Takki()                  # svo að skjárinn mun ekki verða skrítinn þá var nauðsynlegt að setja þetta hér



    def run(self):
        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150)      # Hér er búin til hlutur. Vísað er í Kóðann Generals og klassann frame
        screen = screen1.uppsetning()                           # Hér er búin til ramminn
        game_over = False

        while not game_over:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            screen.blit(bg,(0,0))   # Hér er birt myndin 'Reynduaftur.png'
            self.button.button("Reyndu aftur", 300,330,190,40,self.WHITE,self.RED)
            # Hér lentum víð í einhverju veseni með að nota button.button() fallið og var því ákveðið að notaður
            # eftirfarandi kóða.
            # Hér er notað föllin mouse.get_pos() og .get_pressed() til þess að ákveða hvar á að ýta til þess að
            # keyra fallið staedaemi.run() aftur.
            self.mouse = pygame.mouse.get_pos()         # Fallið greinir það hvar músin er staðsett
            self.click = pygame.mouse.get_pressed()     # Fallið greinir það að klkkað er með tölvumúsinni

            if 300+190 > self.mouse[0]  > 300 and 330 + 40  > self.mouse[1] > 330:
                if self.click[0] == 1:
                    # Svo að hægt sé að fara oftar en einusinni tilbaka þá er nauðsynlegt að
                    # búa til hlutinn staedaemi og kalla á fallið .run()
                    # Fyrst var einungis notað import staedaemi. En þá virkaði það bara einu sinni
                    import staedaemi
                    staedaemi = staedaemi.levelinbetweenstae()
                    staedaemi.run()

            pygame.display.update()

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
