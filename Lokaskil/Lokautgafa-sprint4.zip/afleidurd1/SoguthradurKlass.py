import pygame
import os
from Button import Takki
from levelinbetween import LevelMilli
import Generals as G


pygame.init()


class Soguthradur:
    def __init__(self):
        self.WIDTH = 799 #Breidd skjás
        self.HEIGHT = 500 #Hæð skjás
        self.clock = pygame.time.Clock()
        self.mynd = pygame.image.load('Scientology.jpg') #Bakgrunnur skjás
        self.saga = pygame.image.load('Soguthradur.png') #Texti með söguþráð leiksins
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)

    def image(self,background,x,y):
        self.screen.blit(background,(x,y)) #fall sem blittar mynd

    def story(self):
        button =Takki()
        level = LevelMilli()
        self.screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150) # Hér er búin til hlutur. Vísað er í Kóðann Generals og klassann frame
        self.screen = self.screen1.uppsetning()


        while True:
            for event in pygame.event.get():
                G.Exit.exit(event)


            self.screen.fill(self.WHITE)
            self.image(self.mynd,0,0)
            self.image(self.saga,50,200)

            button.button('Hætta',650,300,125,50,self.GOLD,self.BRIGHT_GOLD,pygame.quit)
            button.button('Spila',515,300,125,50,self.RED,self.BRIGHT_RED,level.run)
            pygame.display.update()
            self.clock.tick(15)
