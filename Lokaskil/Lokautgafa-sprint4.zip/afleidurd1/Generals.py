import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *
import thu_tapadir
tap1=thu_tapadir.tilbaka_i
class Exit:
    def exit(event):
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                sys.exit()

class position:                             # Þessi klassi er notaður til þess að hreyfa kallinn
    def __init__(self,x,y,pr_left,pr_right,pr_up,pr_down):
        self.x = x
        self.y = y
        self.pr_left= pr_left
        self.pr_right=pr_right
        self.pr_up  = pr_up
        self.pr_down= pr_down

    def true_not(self,event):               # Þessi klassi er nauðsynlegur svo hægt sé að halda inni takkanum til þess að færa kallinn
        pygame.init()
        if event.type == pygame.KEYDOWN:    # Ef örfatakkarnir eru niðri þá er sá takki skráður sem true og kallinn labbar þangað
            if event.key == pygame.K_LEFT:
                self.pr_left = True
            if event.key == pygame.K_RIGHT:
                self.pr_right= True
            if event.key == pygame.K_UP:
                self.pr_up   = True
            if event.key == pygame.K_DOWN:
                self.pr_down = True

        if event.type == pygame.KEYUP:  # Ef örfatakkinn er slepptur þá er hann skráður sem false og hann labbar ekki í þá átt lengur
            if event.key == pygame.K_LEFT:
                self.pr_left = False
            if event.key == pygame.K_RIGHT:
                self.pr_right = False
            if event.key == pygame.K_UP:
                self.pr_up   = False
            if event.key == pygame.K_DOWN:
                self.pr_down = False
    def walk(self,file1,file2,file3,file4,TorN):                     # Hér er kallinn látinn labba í þá átt sem örfatakkinn er skráður sem true
        pygame.init()
#        x=self.x
#        y=self.y

        if self.pr_left:                # Vinstri
            self.x -=(13/2)
        if self.pr_right:               # Hægri
            self.x +=(13/2)
        if self.pr_up:                  # Upp
            self.y -=(13/2)
        if self.pr_down:                # Niður
            self.y +=(13/2)
#        if x==self.y and y==self.y:
#
        self.Walkback(file1,file2,file3,file4,TorN)                 # Her er vísað í annað fall sem athugar hvort sé verið að labba á skorðu
                                        # Ef labbað er á skorðu þá er labbað tilbaka
        return [self.x,self.y]

    def Walkback(self,file1,file2,file3,file4,TorN):                 # Þessi klassi lætur kallinn labba tilbaka ef labbað er á skorðu/vegg
        filename1=file1      # þessi tvö gagnasöfn eru fyrir skorður
        filename2=file2       # Eitt gagnsafn er notað fyrir neðrihluta skjásins og hitt fyrir efri hlutann
        filename3=file3
        filename4=file4
        if self.y >= 403 and self.x>=682.5 and TorN:               # Skoðað gagnasafn 1 ef kallinn er á efri hluta skjásins
            f = open(filename1, 'r');
            texti = str(self.x)+','+str(self.y)+'\n';
            for line in f.readlines(): # Hér er skoðað allar skorðurnar á efrihluta skjásins

                if texti == line:      # ef ein skorðan er það sama og staðsetningin sem verið er að labba á, þá er labbað tilbaka
                    if self.pr_left:
                        self.x +=(13/2)     # Hér er labbað tilbaka
                    if self.pr_right:
                        self.x -=(13/2)
                    if self.pr_up:
                        self.y +=(13/2)
                    if self.pr_down:
                        self.y -=(13/2)

        elif self.y <= 403 and self.x>=682.5 and TorN:
            f = open(filename2, 'r');
            texti = str(self.x)+','+str(self.y)+'\n';

            for line in f.readlines():
                if texti == line:
                    if self.pr_left:
                        self.x +=(13/2)
                    if self.pr_right:
                        self.x -=(13/2)
                    if self.pr_up:
                        self.y +=(13/2)
                    if self.pr_down:
                        self.y -=(13/2)
        elif self.y >= 403 and self.x <= 682.5 and TorN:
            f = open(filename3, 'r');
            texti = str(self.x)+','+str(self.y)+'\n';

            for line in f.readlines():
                if texti == line:
                    if self.pr_left:
                        self.x +=(13/2)
                    if self.pr_right:
                        self.x -=(13/2)
                    if self.pr_up:
                        self.y +=(13/2)
                    if self.pr_down:
                        self.y -=(13/2)
        elif self.y <= 403 and self.x <= 682.5 and TorN:
            f = open(filename4, 'r');
            texti = str(self.x)+','+str(self.y)+'\n';

            for line in f.readlines():
                if texti == line:
                    if self.pr_left:
                        self.x +=(13/2)
                    if self.pr_right:
                        self.x -=(13/2)
                    if self.pr_up:
                        self.y +=(13/2)
                    if self.pr_down:
                        self.y -=(13/2)
        elif TorN==False:
            f = open(filename1, 'r');
            texti = str(self.x)+','+str(self.y)+'\n';

            for line in f.readlines():
                if texti == line:
                    print("virkar")
                    if self.pr_left:
                        self.x +=(13/2)
                    if self.pr_right:
                        self.x -=(13/2)
                    if self.pr_up:
                        self.y +=(13/2)
                    if self.pr_down:
                        self.y -=(13/2)


class birtan():                 #Þetta er aukaklassi sem lýsir upp skjáinn þegar labbað er útur hellinum
    def __init__(self,x,y,display,stor_eda_smar):
        self.x = x
        self.y = y
        self.DISPLAYSURF2=display
        self.s_e_s = stor_eda_smar
    def skuggi(self):
        if self.s_e_s:
            pygame.draw.circle(self.DISPLAYSURF2, [0,0,0], [int(self.x)+5,int(self.y) +5], 1020,780)
            pygame.draw.rect(  self.DISPLAYSURF2, [0,0,0], (0,0, 705, 1000))
        else:
            pygame.draw.circle(self.DISPLAYSURF2, [0,0,0], [int(self.x)+5,int(self.y) +5], 1020,980)
            pygame.draw.rect(  self.DISPLAYSURF2, [0,0,0], (0,0, 705, 1000))
    def brightness(self):

        if   self.x >= 682.5:
            pass
        else:
            for i in range(255):
                pygame.draw.circle(self.DISPLAYSURF2, [i,i,i],          [int(self.x)+5,int(self.y) +5], 1520)
                pygame.display.update()


            pygame.draw.circle(self.DISPLAYSURF2, [255,255,255],          [int(self.x)+5,int(self.y) +5], 1520)
            pygame.display.update()
            time.sleep(0.5)
            return True
            #pygame.draw.rect(self.DISPLAYSURF2, [255,255,255],(682.5-6.25*8,0,905,1000))
            #pygame.draw.rect(  self.DISPLAYSURF2, [255,255,255], (0,0, 705, 1000))
            #time.sleep(1.0)

class frame:                    # Þessi klassi er notaður til þess að búa til gluggann
    def __init__(self,x1,y1,x2,y2):
        self.x1=x1
        self.y1=y1
        self.x2=x2
        self.y2=y2
    def uppsetning(self):
        os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (self.x2,self.y2)    #setur vinstra og efra hornið á tölvuleikjaskjánum upp vinstramegin á tölvuskjánnum
        pygame.init()
        DISPLAYSURF = pygame.display.set_mode((self.x1,self.y1))
        pygame.FULLSCREEN
        return DISPLAYSURF

class skorddur(object):                     # Þessi klassi er einungis notaður þegar verið er að búa til skorðurnar í leiknum
    def __init__(self,f1,f2,f3,f4,auto,x_0,y_0,):  # Hann er ekki notaður þegar tölvuleikurinn er keyrður og má því verða eyddur þegar leikurinn er klár til sölu
        self.f1 = f1
        self.f2 = f2
        self.f3 = f3
        self.f4 = f4
        self.auto = auto
        self.x_0 = x_0
        self.y_0 = y_0
    def skordu(self,event,x,y):

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_e:
                self.f1.write(str(x)+","+str(y+6.5)+"\n")
            if event.key == pygame.K_f:
                self.f1.write(str(x+6.5)+","+str(y)+"\n")
            if event.key == pygame.K_s:
                self.f1.write(str(x-6.5)+","+str(y)+"\n")
            if event.key == pygame.K_x:
                self.f1.write(str(x)+","+str(y-6.5)+"\n")
            if event.key == pygame.K_d:
                self.f2.write(str(x)+","+str(y)+"\n")
            if event.key == pygame.K_r:
                self.f2.write("Eitthvad,\n")
                self.f1.write("Eitthvad,\n")
            if event.key == pygame.K_w:
                if self.auto==False:
                    self.auto=True;
                    print("auto er true")
                    return
                if self.auto==True:
                    self.auto=False;
                    print("auto er false")
                    return
    def skordur2(self,x,y):


        if self.auto and y >= 403 and x>=682.5:               # Skoðað gagnasafn 1 ef kallinn er á efri hluta skjásins
            self.f1.write(str(x)+","+str(y)+"\n")

        elif self.auto and y <= 403 and x>=682.5:
            self.f2.write(str(x)+","+str(y)+"\n")
        elif self.auto and y >= 403 and x <= 682.5:
            self.f3.write(str(x)+","+str(y)+"\n")
        elif self.auto and y <= 403 and x <= 682.5:
            self.f4.write(str(x)+","+str(y)+"\n")

class JohnTravolta(object):
    def __init__(self):
        self.player2=[1248,559]
        self.teljari=0
        self.a=[]
        self.teljari2=-1
        self.TorF = True
    def hallo(self,Display_2):
        #Johhnarinn
        return pygame.draw.rect(Display_2, (0,0,0), (self.player2[0],self.player2[1], 8, 8))

    def einusinni(self,Display_2,x,y,Mapwidth,Mapheight,colours,tilemap,Tilesize):
         pygame.draw.rect(Display_2, (33, 125, 34), (self.player2[0]-x,self.player2[1], 8, 8))
         tala=0
         for i in range(10):
             time.sleep(0.1)
             for row in range(Mapheight):         #ROÐ 1 UPPÍ 24
                 for column in range(Mapwidth):   #DÁLKUR 1 UPPÍ 38
                     pygame.draw.rect(Display_2,   colours[tilemap[row][column]],   (column*Tilesize, row*Tilesize,Tilesize,Tilesize))
             self.player2[0]=self.player2[0]-13/2
             pygame.draw.rect(Display_2, (0,0,0), (self.player2[0],self.player2[1], 8, 8))

             pygame.draw.rect(Display_2, (85,77,0), (x,y, 8, 8))
             pygame.display.update()
         return pygame.draw.rect(Display_2, (0,0,0), (self.player2[0],self.player2[1], 8, 8))

    def eltingarleikur1(self,Display_2,xx,yy):
         x=self.player2[0]-xx
         y=self.player2[1]-yy
         if x!=0:
             if x<0 and (self.player2[1]<435.5):
                 self.player2[0]=self.player2[0]+13/2
             if x>0 and (self.player2[1]<435.5):
                 self.player2[0]=self.player2[0]-13/2
         if y!=0:
             if y<0:
                 self.player2[1]=self.player2[1]+13/2
             if y>0:
                 self.player2[1]=self.player2[1]-13/2
         self.teljari=self.teljari+1
         return pygame.draw.rect(Display_2, (33, 125, 34), (self.player2[0],self.player2[1], 8, 8))
    def leikur1buin(self,x,y):
         if self.player2[0]==x and self.player2[1]==y:
             return False
         return True
    def fylki(self,xx,yy):
        self.a.append([xx,yy])
        if len(self.a)==range(37):
            del(self.a[0])
    def eltingarleikur2(self,Display_2,x,y):

        if x==self.player2[0] and y==self.player2[1]:
            self.TorF=False
        on=True
        try:
            while on:
                for i in range(len(self.a)-1):
                    if self.a[i][0]==self.a[1+i][0] and self.a[i][1]==self.a[1+i][1]:
                        del(self.a[i])
                    else:
                        on=False
        except:
            pass


        self.teljari2=self.teljari2+1
        try:
            self.player2[0]=self.a[self.teljari2][0]
            self.player2[1]=self.a[self.teljari2][1]
        except:
            pass

    def TorF(self):
        if self.TorF == False:
            return False
        else:
            return False
    def Playagain(self):
        tap1.Level4()
