import pygame
import sys
import Endurgerd2class
pygame.init()

bg = pygame.image.load('millibord.png')
bg = pygame.transform.scale(bg,(900,500))

class position:
    def __init__(self,x,y,pr_left,pr_right,pr_up,pr_down):
        self.x = x
        self.y = y
        self.pr_left= pr_left
        self.pr_right=pr_right
        self.pr_up  = pr_up
        self.pr_down= pr_down

    def true_not(self,event):
        pygame.init()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.pr_left = True
            if event.key == pygame.K_RIGHT:
                self.pr_right= True
            if event.key == pygame.K_UP:
                self.pr_up   = True
            if event.key == pygame.K_DOWN:
                self.pr_down = True

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.pr_left = False
            if event.key == pygame.K_RIGHT:
                self.pr_right = False
            if event.key == pygame.K_UP:
                self.pr_up   = False
            if event.key == pygame.K_DOWN:
                self.pr_down = False
    def walk(self):
        pygame.init()
        if self.pr_left:
            self.x -= 10
        if self.pr_right:
            self.x += 10
        if self.pr_up:
            self.y -= 10
        if self.pr_down:
            self.y += 10
        return [self.x,self.y]

class levelinbetween:
    def __init__(self):
        self.WIDTH = 900
        self.HEIGHT = 500
        self.RED = (255,0,0)
        self.YELLOW = (255,255,0)
        self.player1_pos = [430, 285]
        self.player1_size = 20
        self.player2_pos = [770,500]
        self.player2_size = 20
        self.sentencecount = 0

    def communication(self, sentencecount):
        if sentencecount == 1:
            print("Setning 1: John Travolta segir ehv")
        elif sentencecount == 2:
            print("Setning 2: Tom Cruise segir ehv")
        elif sentencecount == 3:
            print("Setning 3: John Travolta segir ehv")
        elif sentencecount == 4:
            print("Setning 4: Tom Cruise segir ehv ")
        elif sentencecount == 5:
            print("Setning 5: John Travolta segir ehv ")
        elif sentencecount == 6:
            print("Setning 6: Tom Cruise segir ehv ")


    def run(self):
        screen1 = Endurgerd2class.frame(self.WIDTH, self.HEIGHT)
        screen = screen1.uppsetning()
        game_over = False
        pos = position(self.player1_pos[0],self.player1_pos[1],False,False,False,False)
        sentences = self.sentencecount

        while not game_over:

            pos = position(self.player1_pos[0],self.player1_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)
            xogy = pos.walk()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                pos.true_not(event)

                if self.player1_pos[0] > 720 and self.player1_pos[1] == 500:
                    if event.type == pygame.KEYUP:
                        if event.key == pygame.K_SPACE:
                            sentences   += 1
                            communi = levelinbetween()
                            communi.communication(sentences)

            self.player1_pos[0] = xogy[0]
            self.player1_pos[1] = xogy[1]

            screen.fill((0,0,0))
            screen.blit(bg,(0,0))
            pygame.draw.rect(screen, self.RED, (self.player1_pos[0],self.player1_pos[1], self.player1_size, self.player1_size))
            pygame.display.update()

            pygame.draw.rect(screen, self.YELLOW, (self.player2_pos[0],self.player2_pos[1], self.player2_size, self.player2_size))
            pygame.display.update()

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
