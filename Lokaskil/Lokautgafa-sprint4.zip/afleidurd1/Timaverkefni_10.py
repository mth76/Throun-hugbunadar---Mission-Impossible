
class Thing():
    def __init__(self, pos, remove):
        self.pos = pos
        self.remove = remove
        super().__init__()


    def moveFwd(self,dt): float


    def getName(self):str


    def isAnimal(self):bool


class Animal(Thing):
    def __init__(self,velocity, pos):
        self.dir = 50
        self.pos
        self.velocity = velocity
        super(Animal,self).__init__(self.pos,False)

class Rock(Thing):
    def __init__(self,weight: float):
        self.weight = weight
        super().__init__(pos,remove)


class Ant(Animal):
    def __init__(self, name: str):
        self._name = name
        super(Ant,self).__init__(self.velocity, self.pos)
    def moveFwd(self,dt):
        pass
        return True

    def isAnimal(self):
        pass
        return True
class Ladybug(Animal):
    def __init__(self, pos,velocity):
        self.pFly = 0
        self.name = 'Bug'
        self.pos = pos
        self.velocity = velocity
        super().__init__(pos,velocity)

if __name__ == '__main__':
    l = Ladybug(500.54,4)
    print('Ladybug Nr: 2 name:', l.getName())
