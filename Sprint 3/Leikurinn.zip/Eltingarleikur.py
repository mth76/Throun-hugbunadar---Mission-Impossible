#class frame
#class position
#class

import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *
import Generals as G


class Level3():
    def __init__(self):


        Svartur = (0,  0,  0 )
        Dokkbr  = (58, 26, 12)
        white   = (255,255,255)
        green   = (33, 125, 34)
        wall    = (58, 62,  59)


        o  = 0          # Wall
        x =  1          # Floor
        b  = 2          # Water
        w  = 3
        v  = 4

        self.colours = {            # Hér er verið að skilgreina o,x,g og w sem ákveðna liti
                    o : Svartur,
                    x : green,
                    b : Dokkbr,
                    w : white,
                    v : wall
                        }
        self.tilemap = [
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    [b,b,b,b,b,w,w,w,w,w,w,w,w,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#1
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,v,v,v,x,x,b,b,b,b,b,b,b,b,b,b,b,b],#2
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,v,v,x,x,x,x,b,b,b,b,b,b,b,b,b,b,b],#3
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,v,v,v,v,v,v,v,v,v,x,x,x,v,v,x,x,v,v,x,v,v,v,b,b,b,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,v,v,x,x,v,x,x,b,b,b,b,b,b,b],#5
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,x,x,x,x,x,x,x,b,b,b,b,b,b,b],#6
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,x,v,x,v,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,v,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,v,x,v,x,x,v,x,v,v,v,v,v,x,x,x,x,x,x,x,x,v,x,x,b,b,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,x,v,x,x,x,x,x,v,x,x,x,x,x,v,x,x,x,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,x,v,v,v,v,v,x,v,x,v,v,x,x,x,x,x,x,x,v,x,v,x,x,b,b,b,b,b,b,b],#1
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,v,x,x,x,x,x,x,v,x,v,x,v,v,x,x,v,v,x,x,v,x,x,x,x,x,x,b,b,b,b,b,b],#2
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,v,v,x,v,x,x,x,v,x,v,x,x,x,x,x,v,v,x,x,x,x,x,v,x,x,x,b,b,b,b,b,b],#3
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,v,v,v,x,x,x,x,x,x,x,v,x,v,v,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,b,b,b,b,b],#4
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,v,x,x,v,v,x,x,x,x,b,b,b,b,b],#5
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,v,x,x,x,x,x,x,v,x,x,v,x,x,x,v,v,x,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#6
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,x,x,v,v,v,v,v,v,x,x,x,x,x,x,x,v,x,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#7
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,x,x,x,x,x,x,v,x,x,x,v,x,x,v,x,v,x,v,x,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,x,x,x,x,x,x,x,x,x,v,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,v,x,v,v,v,v,v,v,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,v,v,v,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#1
                    [b,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b,b,v,v,v,v,x,v,x,x,x,x,x,v,x,x,x,x,x,x,x,v,v,v,v,v,x,v,x,x,x,x,x,o,b,b,b,b],#2
                    [b,x,x,x,x,v,x,x,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,v,x,x,x,x,x,v,x,x,x,x,x,o,b,b,b,b],#3
                    [b,x,x,v,v,x,x,x,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,v,x,x,x,x,x,v,x,v,x,x,x,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,v,x,x,b,b,x,x,x,x,v,v,v,x,x,x,x,x,v,v,v,v,v,v,v,v,v,x,x,x,x,x,v,x,x,x,v,x,b,b,b,b,b],#5
                    [b,x,x,x,v,v,v,v,v,v,v,v,x,x,x,x,b,x,x,x,x,x,v,v,x,x,x,x,x,x,x,x,x,x,x,x,v,x,v,x,x,x,v,x,x,x,x,b,b,b,b,b,b],#6
                    [b,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,b,b,x,x,x,x,x,v,v,x,x,x,x,x,x,v,x,x,x,x,v,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,b,x,x,x,x,x,x,x,x,x,x,x,b,b,b,x,x,x,x,v,v,v,v,v,v,v,v,x,x,x,x,v,x,v,v,v,v,v,x,x,b,b,b,b,b,b,b,b],#8
                    [b,x,x,x,x,x,x,x,b,x,x,x,x,x,x,x,x,b,b,b,b,b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#0
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    ]
        self.Tilesize = 26
        self.Mapwidth = 53
        self.Mapheight= 30
        self.RED=(255,0,0)
        #self.player_pos=[1345.5,513.5]
        self.player_pos=[1274.0-13*2,546.0+13]
        self.player_size=8
        self.yfir=False
        self.einusinni1 =1
        self.tala=0
        self.einusinni2=1
        self.eltingarfylki=0
    def run(self):
        Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize)   # Hér er kallað á classann frame í Kóðanum Generals.py
        Display_2 = Display_1.uppsetning()                                              # Hér er kallað á fallið í classanum frame

        game_over = False;                                                              # Game_over er = False þangað til leikurinn er X-aður eða ýtt er á K_ESCAPE
        pos = G.position(self.player_pos[0],self.player_pos[1],False,False,False,False) # pos býr yfir staðsetningu leikmansins
        #skor= G.skorddur(self.f1,self.f2,self.f3,self.f4,False,self.player_pos[0],self.player_pos[1])
        while not game_over:
            Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize)
            pos          = G.position(self.player_pos[0],self.player_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        sys.exit()


                pos.true_not(event)                                             # Þetta fall lætur takkana vera true eða false
                #skor.skordu(event,self.player_pos[0],self.player_pos[1])        # Þetta fall skráir skordur [Takkar: e, f, s, x, d, r, w]


            x = self.player_pos[0]; y = self.player_pos[1];
            xogy = pos.walk("skordur1.txt","skordur2.txt","skordur3.txt","skordur4.txt",True)
            self.player_pos[0] = xogy[0]
            self.player_pos[1] = xogy[1]
            #if x!=self.player_pos[0] or y!=self.player_pos[1]:
            #    skor.skordur2(self.player_pos[0],self.player_pos[1])                # Þetta fall skráir skorðurnar ef ýtt er á

            #pygame.draw.rect(Display_2, self.RED, (x,y, self.player_size,self.player_size))

            #if self.player_pos[1]==383.5:
                #x=JohnTravolta()
                #x.hallo(Display_2)
            for row in range(self.Mapheight):         #ROÐ 1 UPPÍ 24

                for column in range(self.Mapwidth):   #DÁLKUR 1 UPPÍ 38
                    #pygame.draw.rect(  Surface  ,  color  ,  Rect  ,  Width  )
                    #  Surface => DISPLAYSURF2
                    #  Color   => self.colours[  self.tilemap[ röð ][ dalkur ]  ]
                    #  Rect    => ( Dálkur_i * Tilesize,  röð_j * Tilesize , Tilesize, Tilesize)
                    pygame.draw.rect(Display_2,   self.colours[self.tilemap[row][column]],   (column*self.Tilesize, row*self.Tilesize,self.Tilesize,self.Tilesize))
            #Teikna kassann


            if self.player_pos[1]==383.5 and self.einusinni1==1:    #Þetta er keyrt einu sinni. Ég vill ekki keyra classan oftar en einu sinni
                John=G.JohnTravolta()
                self.yfir=True
                self.einusinni1=self.einusinni1+1
                upph_x=self.player_pos[0]
                upph_y=self.player_pos[1]
            if self.yfir==True:
                John.hallo(Display_2)
                if self.einusinni2==1:
                    John.einusinni(Display_2,self.player_pos[0],self.player_pos[1],self.Mapwidth,self.Mapheight,self.colours,self.tilemap,self.Tilesize)
                    self.einusinni2=self.einusinni2+1
                    Elta1=True
                    Elta2=False

                if Elta1:
                    John.eltingarleikur1(Display_2,upph_x,upph_y)
                    John.fylki(self.player_pos[0],self.player_pos[1])
                    Elta1=John.leikur1buin(upph_x,upph_y)
                    if Elta1==False:
                        Elta2=True

                if Elta2:
                    John.eltingarleikur2(Display_2,self.player_pos[0],self.player_pos[1])


            time.sleep(0.02)

            pygame.draw.rect(Display_2, self.RED, (self.player_pos[0],self.player_pos[1], self.player_size, self.player_size))
            # Kominn útur Hellinum
            pygame.display.update()
def main():

    volun=Level3()
    volun.run()
if __name__ == "__main__":
    main()
