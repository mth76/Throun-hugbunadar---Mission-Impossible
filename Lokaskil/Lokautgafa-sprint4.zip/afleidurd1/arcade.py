#class frame
#class position
#class

import pygame, sys, os, time
from math import pi
pygame.init()
from pygame.locals import *
import Generals as G

class Level3():
    def __init__(self):
        Svartur = (0,  0,  0 )
        Dokkbr  = (58, 26, 12)
        white   = (255,255,255)
        green   = (33, 125, 34)
        wall    = (58, 62,  59)
        vidbaett= (180,180,180)


        o  = 0          # Wall
        x =  1          # Floor
        b  = 2          # Water
        w  = 3
        v  = 4
        X = 5

        self.colours = {            # Hér er verið að skilgreina o,x,g og w sem ákveðna liti
                    o : Svartur,
                    x : green,
                    b : Dokkbr,
                    w : white,
                    v : wall,
                    X : vidbaett
                        }
        self.tilemap = [
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    [b,b,b,b,b,w,w,w,w,w,w,w,w,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#1
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,X,x,x,x,X,x,x,x,x,x,x,v,v,v,v,x,x,b,b,b,b,b,b,b,b,b,b,b,b],#2
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,X,x,x,x,X,x,x,x,x,x,x,x,x,v,v,v,x,x,x,x,b,b,b,b,b,b,b,b,b,b,b],#3
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,v,x,X,v,v,v,v,v,v,v,v,v,x,x,x,v,v,x,x,v,v,x,v,v,v,b,b,b,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,x,x,x,x,x,x,v,v,x,x,v,v,x,x,v,x,x,b,b,b,b,b,b,b],#5
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,X,x,v,x,x,x,x,x,X,X,x,x,X,x,v,v,x,x,X,x,x,x,X,x,x,b,b,b,b,b,b,b],#6
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,v,x,x,x,x,x,X,x,x,x,x,x,v,v,x,x,x,v,x,X,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,X,v,x,v,x,X,x,x,X,x,X,x,x,x,x,x,v,x,X,x,x,x,x,x,b,b,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,v,x,v,x,x,v,x,v,v,v,v,v,x,x,x,x,X,X,x,x,v,x,x,b,b,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,x,v,x,x,x,X,x,v,x,x,X,x,x,v,x,x,x,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,x,X,x,v,v,v,v,v,x,v,x,v,v,x,x,x,x,X,x,x,v,x,v,x,x,b,b,b,b,b,b,b],#1
                    [b,b,b,b,b,b,b,X,X,X,x,b,b,b,b,b,b,b,b,b,v,v,x,x,x,x,x,x,v,x,v,x,v,v,x,x,v,v,x,x,v,x,x,x,x,X,x,b,b,b,b,b,b],#2
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,b,b,b,v,v,v,x,v,X,x,x,v,x,v,x,x,X,x,x,v,v,x,x,x,x,x,v,x,x,x,b,b,b,b,b,b],#3
                    [b,b,b,b,b,b,b,x,X,X,X,b,b,b,b,b,b,v,v,v,v,x,x,x,x,x,x,x,v,x,v,v,x,x,x,x,X,x,x,X,X,x,x,x,x,x,x,x,b,b,b,b,b],#4
                    [b,b,b,b,b,b,b,x,X,x,x,b,b,b,b,b,b,v,x,x,x,x,x,v,X,x,X,x,v,x,x,v,x,x,x,X,x,x,X,v,x,x,v,v,x,x,x,x,b,b,b,b,b],#5
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,x,v,x,x,x,x,x,x,v,x,x,v,X,X,x,v,v,x,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#6
                    [b,b,b,b,b,b,b,X,X,X,x,b,b,b,b,b,b,v,x,x,x,x,X,v,v,v,v,v,v,x,X,X,X,x,x,x,v,X,x,v,x,x,v,x,x,x,x,x,b,b,b,b,b],#7
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,x,x,x,x,x,X,v,x,x,x,v,x,x,v,x,v,x,v,x,b,b,b,b,b],#8
                    [b,b,b,b,b,b,b,x,x,X,x,b,b,b,b,b,b,v,x,x,v,x,x,v,v,v,v,v,v,X,x,x,X,X,x,x,x,x,v,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#9
                    [b,b,b,b,b,b,b,x,x,x,x,b,b,b,b,b,b,v,x,x,v,v,x,v,v,v,v,v,v,x,X,x,X,X,x,X,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,x,x,X,X,b,b,b,b,b,b,v,x,x,x,x,x,x,x,v,v,v,v,x,x,x,x,X,x,x,x,x,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b],#1
                    [b,x,x,x,x,v,x,x,x,x,x,b,b,b,b,b,b,v,v,v,v,x,v,x,x,x,x,x,v,x,x,x,X,x,x,x,v,v,v,v,v,x,v,x,x,x,x,x,o,b,b,b,b],#2
                    [b,x,x,x,x,v,x,X,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,x,x,x,X,x,v,x,x,x,x,x,v,x,x,x,x,x,o,b,b,b,b],#3
                    [b,x,x,v,v,x,x,x,x,x,x,v,x,x,x,x,x,x,x,x,v,x,x,x,x,v,x,x,v,x,x,X,x,x,X,x,v,x,x,x,x,x,v,x,v,x,x,x,b,b,b,b,b],#4
                    [b,x,x,x,x,x,x,x,x,x,x,v,x,x,b,b,x,x,x,x,v,v,v,x,x,x,x,x,v,v,v,v,v,v,v,v,v,x,x,x,x,x,v,x,x,x,v,x,b,b,b,b,b],#5
                    [b,x,x,x,v,v,v,v,v,v,v,v,x,x,x,x,b,x,x,X,x,x,v,v,x,x,x,x,x,x,x,x,x,x,X,x,v,x,v,x,x,x,v,x,x,x,x,b,b,b,b,b,b],#6
                    [b,x,x,X,x,x,x,x,x,x,x,v,X,x,x,x,b,b,x,x,x,x,x,v,v,x,x,x,x,x,x,v,X,x,x,x,v,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b],#7
                    [b,x,x,x,x,b,x,x,x,x,x,x,x,x,x,x,x,b,b,b,x,x,x,x,X,v,v,v,X,v,v,v,x,X,x,x,v,x,v,v,v,v,v,x,x,b,b,b,b,b,b,b,b],#8
                    [b,x,x,x,x,x,x,x,b,x,x,x,x,x,x,x,x,b,b,b,b,b,x,x,x,x,x,x,x,x,x,x,x,x,x,x,v,x,x,x,x,x,x,x,b,b,b,b,b,b,b,b,b],#0
                    [b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b],#0
                    #1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8  9 0 1 2 3
                    ]
        self.Tilesize = 26
        self.Mapwidth = 53
        self.Mapheight= 30
        self.RED=(255,0,0)
        #self.player_pos=[1345.5,513.5]
        self.player_pos=[1274.0-13*2,546.0+13]
        self.player_size=8
        self.yfir=False
        self.einusinni1 =1
        self.tala=0
        self.einusinni2=1
        self.eltingarfylki=0
    def run(self):
        Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize)   # Hér er kallað á classann frame í Kóðanum Generals.py
        Display_2 = Display_1.uppsetning()                                              # Hér er kallað á fallið í classanum frame

        game_over = False;                                                              # Game_over er = False þangað til leikurinn er X-aður eða ýtt er á K_ESCAPE
        pos = G.position(self.player_pos[0],self.player_pos[1],False,False,False,False) # pos býr yfir staðsetningu leikmansins

        #Klukkan
        self.clock = pygame.time.Clock()
        font = pygame.font.Font(None, 25)
        frame_count = 0
        frame_rate = 60
        start_time = 0
        while not game_over:

            # Klukkan
            total_seconds = frame_count // frame_rate
            minutes = total_seconds // 60
            seconds = total_seconds % 60
            total_seconds = start_time + (frame_count // frame_rate)
            #if total_seconds < 0:
            #total_seconds = 0
            seconds = total_seconds % 60
            output_string = "Time left: {0:02}".format(seconds)
            text = font.render(output_string, True, [0,0,0])
            Display_2.blit(text, [400, 25])
            frame_count += 1
            self.clock.tick(frame_rate)
            pygame.display.flip()
            self.clock.tick(60)

            # Skjárinn
            Display_1 = G.frame(self.Mapwidth*self.Tilesize,self.Mapheight*self.Tilesize)

            # Instance fyrir staðsetninguna og hreyfingar
            pos = G.position(self.player_pos[0],self.player_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)

            # Ef ýtt er á takka
            for event in pygame.event.get():
                # Exit ef ýtt er á X knappinn eða ESC
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        sys.exit()
                # Ef haldið er niðri örfatakkanum þá er labbað
                pos.true_not(event)

            # Fall sem lætur kallinn labba og ekki labba í gegnum skorður
            xogy = pos.walk("skordur1.txt","skordur2.txt","skordur3.txt","skordur4.txt",True)
            self.player_pos[0] = xogy[0]
            self.player_pos[1] = xogy[1]

            for row in range(self.Mapheight):         #ROÐ 1 UPPÍ 24
                for column in range(self.Mapwidth):   #DÁLKUR 1 UPPÍ 38
                    #pygame.draw.rect(  Surface  ,  color  ,  Rect  ,  Width  )
                    #  Surface => DISPLAYSURF2
                    #  Color   => self.colours[  self.tilemap[ röð ][ dalkur ]  ]
                    #  Rect    => ( Dálkur_i * Tilesize,  röð_j * Tilesize , Tilesize, Tilesize)
                    pygame.draw.rect(Display_2,   self.colours[self.tilemap[row][column]],   (column*self.Tilesize, row*self.Tilesize,self.Tilesize,self.Tilesize))

            pygame.draw.rect(Display_2, self.RED, (self.player_pos[0],self.player_pos[1], self.player_size, self.player_size))

            time.sleep(0.03)
            pygame.display.update()
def main():

    volun=Level3()
    volun.run()
if __name__== "__main__":
    main()
