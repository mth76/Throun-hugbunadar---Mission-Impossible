import pygame
import Endurgerd2class
pygame.init()
import sys
import Button

bg = pygame.image.load('algebrad1.png')
bg = pygame.transform.scale(bg,(799,500))
button = Button.Button()

class levelinbetween:
    def __init__(self):
        self.WIDTH = 799
        self.HEIGHT = 500
        self.RED = (200,0,0)
        self.WHITE = (255, 255, 255)

    def run(self):
        screen1 = Endurgerd2class.frame(self.WIDTH, self.HEIGHT)
        screen = screen1.uppsetning()
        game_over = False
        while not game_over:

            for event in pygame.event.get():
                print(pygame.mouse.get_pos())
                if event.type == pygame.QUIT:
                    sys.exit()

            screen.blit(bg,(0,0))
            button.button1(64,393,191,65)
            button.button1(326,393,174,65)
            button.button1(578,393,174,65)
            #screen.blit(bg,(0,0))
            pygame.display.update()
            #button.button("ALGEBRA", 300,300, 20,40,self.RED,self.RED)

def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
