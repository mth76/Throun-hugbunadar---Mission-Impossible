
from Level4 import Level4class


class tilbaka_i:
    def __init__():
        pass
    def Level1():
        pass#level1.game_loop()
    def Level4():
        level4 = Level4class()
        level4.run()
