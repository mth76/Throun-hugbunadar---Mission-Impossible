import pygame
import os



class Takki:
    def __init__(self):
        self.WIDTH = 800
        self.HEIGHT = 800
        self.BLACK = (0,0,0)
        self.WHITE = (255, 255, 255)
        self.RED = (200,0,0)
        self.BRIGHT_RED = (255,0,0)
        self.GREEN = (0,200,0)
        self.BRIGHT_GREEN = (0,255,0)
        self.GOLD = (225,215,0)
        self.BRIGHT_GOLD = (255,215,0)
        self.WIDTH = 1440
        self.HEIGHT = 853
        self.screen=pygame.display.set_mode((self.WIDTH,self.HEIGHT))

    def text_objects(self,text,font):
        self.textSurface = font.render(text,True,self.BLACK)
        return self.textSurface, self.textSurface.get_rect()

    def message_display(text):
        largeText = pygame.font.Font('freesansbold.ttf',20)
        TextSurf, TextRect = text_objects(text, largeText)
        TextRect.center = ((self.WIDTH/2),(self.HEIGHT/2))
        gameDisplay.blit(TextSurf, TextRect)

    def button(self,msg,x,y,w,h,ic,ac, action=None):
        self.mouse = pygame.mouse.get_pos()
        self.click = pygame.mouse.get_pressed()
        if x + w > self.mouse[0] > x and y + h > self.mouse[1] >y:
            pygame.draw.rect(self.screen,ac,(x,y,w,h))
            if self.click[0] == 1 and action != None:
                action()
        else:
            pygame.draw.rect(self.screen,ic,(x,y,w,h))

        self.smallText = pygame.font.Font("freesansbold.ttf", 23)
        self.textSurf, self.textRect = self.text_objects(msg, self.smallText)
        self.textRect.center = ((x + (w/2)), (y + (h/2)))
        self.screen.blit(self.textSurf,self.textRect)
        self.textSurf,self. textRect = self.text_objects(msg, self.smallText)
        self.textRect.center = ((x + (w/2)), (y + (h/2)))
        self.screen.blit(self.textSurf,self.textRect)
        self.textSurf, self.textRect = self.text_objects(msg, self.smallText)
        self.textRect.center = ((x + (w/2)), (y + (h/2)))
        self.screen.blit(self.textSurf,self.textRect)

    def button1(self,x,y,w,h,action=None):
        self.mouse = pygame.mouse.get_pos()
        self.click = pygame.mouse.get_pressed()
        if x + w > self.mouse[0] > x and y + h > self.mouse[1] >y:
            print("eg ytti a shittid")
            if self.click[0] == 1 and action != None:
                action()
