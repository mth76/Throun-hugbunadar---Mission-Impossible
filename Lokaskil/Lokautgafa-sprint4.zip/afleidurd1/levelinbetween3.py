import pygame
import sys
import Generals as G
from Level3 import Level3class

pygame.init()

bg = pygame.image.load('millibord3.png')
bg = pygame.transform.scale(bg,(900,500))
Tomcruise = pygame.image.load('TomCruise.png')
Johntravolta= pygame.image.load('JohnTravolta2.png')
Lronhubbard= pygame.image.load('L.Ron.Hubbard.png')
textbox1= pygame.image.load('Textbox1millibord3.png')
textbox2= pygame.image.load('Textbox2millibord3.png')
textbox3= pygame.image.load('Textbox3millibord3.png')
textbox4= pygame.image.load('Textbox4millibord3.png')
textbox5= pygame.image.load('Textbox5millibord3.png')
textbox6= pygame.image.load('Textbox6millibord3.png')

class LevelMilli3:
    def __init__(self):
        self.WIDTH = 900
        self.HEIGHT = 500
        self.RED = (255,0,0)
        self.YELLOW = (255,255,0)
        self.player1_pos = [405, 203]
        self.player1_size = 20
        self.player2_pos = [700,400]
        self.player2_size = 20
        self.player3_pos = [320,230]
        self.player3_size = 20
        self.textbox_pos = [635,275]
        self.textbox1_pos = [635,275]
        self.textbox2_pos = [500,275]
        self.textbox3_pos = [265,140]
        self.sentencecount = 0

    def communication(self, sentencecount):
        if sentencecount == 1:
            print("Setning 1: John Travolta segir ehv")
        elif sentencecount == 2:
            print("Setning 2: Tom Cruise segir ehv")
        elif sentencecount == 3:
            print("Setning 3: John Travolta segir ehv")
        elif sentencecount == 4:
            print("Setning 4: Tom Cruise segir ehv ")
        elif sentencecount == 5:
            print("Setning 5: John Travolta segir ehv ")
        elif sentencecount == 6:
            print("Setning 6: Tom Cruise segir ehv ")
        return


    def run(self):
        screen1 = G.frame(self.WIDTH, self.HEIGHT,200,150)
        screen = screen1.uppsetning()
        game_over = False
        pos = G.position(self.player1_pos[0],self.player1_pos[1],False,False,False,False)
        sentences = self.sentencecount

        while not game_over:

            pos = G.position(self.player1_pos[0],self.player1_pos[1],pos.pr_left,pos.pr_right,pos.pr_up,pos.pr_down)
            xogy = pos.walk("empty.txt","empty.txt","empty.txt","empty.txt", True)
            #print(xogy)

            for event in pygame.event.get():
                G.Exit.exit(event)
                pos.true_not(event)

                if self.player1_pos[0]  > 600 and self.player1_pos[1] > 400:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE and sentences <= 5:
                            sentences   += 1

                if self.player1_pos[0] > 600 and self.player1_pos[1] > 400:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE and sentences > 5:
                            sentences   += 1


            self.player1_pos[0] = xogy[0]
            self.player1_pos[1] = xogy[1]

            bord3 = Level3class()
            screen.blit(bg,(0,0))

            screen.blit(Lronhubbard, (self.player3_pos[0],self.player3_pos[1]))


            if sentences == 1:
                screen.blit(textbox1, (self.textbox_pos[0],self.textbox_pos[1]))
            elif sentences == 2:
                screen.blit(textbox2, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 3:
                screen.blit(textbox3, (self.textbox2_pos[0],self.textbox2_pos[1]))
            elif sentences == 4:
                screen.blit(textbox4, (self.textbox1_pos[0],self.textbox1_pos[1]))
            elif sentences == 5:
                screen.blit(textbox5, (self.textbox2_pos[0],self.textbox2_pos[1]))
            elif sentences == 7:
                screen.blit(textbox6, (self.textbox3_pos[0],self.textbox3_pos[1]))
            elif sentences == 8:
                bord3.run()



            screen.blit(Tomcruise, (self.player1_pos[0],self.player1_pos[1]))

            screen.blit(Johntravolta, (self.player2_pos[0],self.player2_pos[1]))
            pygame.display.update()




def main():
    game = levelinbetween()
    game.run()

if __name__ == '__main__':
    main()
