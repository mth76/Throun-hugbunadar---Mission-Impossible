import pygame, os, sys
from SoguthradurKlass import Soguthradur
from Button import Takki
from levelinbetween import LevelMilli
from Leidbeiningar import Controls





class Menu:
    def __init__(self):
        self.WIDTH =         799 #Skilgreini breidd skjás
        self.HEIGHT =        500 #Skilgreini hæð skjás
        self.BLACK =         (0,0,0)   #Liturinn svartur
        self.WHITE =         (255, 255, 255)  #Liturinn hvítur
        self.RED =           (200,0,0)    #Liturinn rauður
        self.BRIGHT_RED =    (255,0,0)     #Liturinn skær rauður
        self.GREEN =         (0,200,0)     #Liturinn grænn
        self.BRIGHT_GREEN =  (0,255,0)     #Liturinn skær rauður
        self.GOLD =          (225,215,0)    #Liturinn gull
        self.BRIGHT_GOLD =   (255,215,0)    #Liturinn skær gull
        self.ORANGE =        (255,100,0)    #Liturinn appelsínugulur
        self.BRIGHT_ORANGE = (255,165,0)    #Liturinn skær appelsínugulur

        pygame.init()
        pygame.font.init()
        pygame.display.set_caption("Mission Impossible")
        self.clock = pygame.time.Clock()
        self.background = pygame.image.load('Scientology.jpg') #hlaða inn bakgrunn
    def image(self,background,x,y):
        self.screen.blit(background,(x,y)) #fall sem blittar mynd

    def game_intro(self):
        pygame.init()
        self.screen = pygame.display.set_mode((self.WIDTH,self.HEIGHT)) #Hæð og Breidd skjás

        #pygame.mixer.music.load("MissionImpossible.mp3")  #Tónlist fyrir leikinn
        #pygame.mixer.music.play(-1)
        storyKlasi= Soguthradur()
        button=Takki()
        level=LevelMilli()
        leidbeiningar =Controls()
        while True:

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        sys.exit()
            self.screen.fill((0,0,0))

            self.image(self.background,0,0)

            button.button('Söguþráður',20,350,150,75,self.RED,self.BRIGHT_RED,storyKlasi.story) #Býr til takka sem kallar síðan á söguþráðinn
            button.button('Spila',220,350,150,75,self.GREEN,self.BRIGHT_GREEN,level.run) #Takki sem fer í borð 1
            button.button('Hætta',420,350,150,75,self.GOLD,self.BRIGHT_GOLD,pygame.quit) #Takki til að hætta
            button.button('Leiðbeiningar',620,350,175,75,self.ORANGE,self.BRIGHT_ORANGE,leidbeiningar.leid) #Takki sem sýnir síðan leiðbeiningar fyrir leikinn.

            pygame.display.update()
            self.clock.tick(15)

if __name__ == '__main__':
    menu = Menu()
    menu.game_intro()

    pygame.quit()
    quit()
