import unittest
import Menu
import levelinbetween


class TestStrings(unittest.TestCase):
    def klasar(self):
        self.Menu = Menu.Menu()
        self.levels = levelinbetween.levelinbetween()

    def TestMenu(self):
        self.assertIsInstance(self.menu, Menu.Menu)

    def TestLevels(self):
        Self.assertIsInstance(self.levels, levelinbetween.levelinbetween)

if __name__ == '__main__':
    unittest.main()
